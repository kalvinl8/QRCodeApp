<?php

//define("DATABASE_HOST", "localhost");
//define("DATABASE_NAME", "id2400930_qrcodescanner");
//define("DATABASE_USER", "id2400930_usman12546");
//define("DATABASE_PASSWORD", "usman12546");
//define("DEBUG", false);
//define('BASE_URL', 'http://qrcodescannerpro.000webhostapp.com/');

define("DATABASE_HOST", "localhost");
define("DATABASE_NAME", "qrcodescanpro");
define("DATABASE_USER", "root");
define("DATABASE_PASSWORD", "root");
define("DEBUG", true);
define('BASE_URL', 'http://localhost/qrcodescanpro/');