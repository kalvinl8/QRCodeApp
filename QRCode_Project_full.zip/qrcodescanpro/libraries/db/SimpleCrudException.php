<?php

namespace SimpleCrud;

class SimpleCrudException extends \Exception
{
}
