<?php

namespace SimpleCrud\Fields;

/**
 * Normalices date values.
 */
class Date extends Datetime
{
    protected $format = 'Y-m-d';
}
