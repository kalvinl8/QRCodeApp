<?php

namespace SimpleCrud\Queries\Sqlite;

use SimpleCrud\Queries\Mysql\Select as BaseSelect;

/**
 * Manages a database select query in Sqlite databases.
 */
class Select extends BaseSelect
{
}
