﻿using System;
using System.ComponentModel;
using CoreAnimation;
using CoreGraphics;
using Foundation;
using QRCodePro.iOS.Renderers;
using QRCodePro.Widgets;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(ImageEntry), typeof(ImageEntryRenderer))]
namespace QRCodePro.iOS.Renderers
{
	public class ImageEntryRenderer : EntryRenderer
	{
		public override void Draw(CGRect rect)
		{
			base.Draw(rect);

			var textField = this.Control;
			var element = (ImageEntry)this.Element;

			CALayer bottomBorder = new CALayer
			{
				Frame = new CGRect(0.0f, this.Frame.Height - 2, this.Frame.Width, 1f),
				BorderWidth = 1.0f,
				BackgroundColor = element.BorderColor.ToCGColor(),
				BorderColor = element.BorderColor.ToCGColor()
			};

			textField.Layer.AddSublayer(bottomBorder);
			textField.Layer.MasksToBounds = true;
		}

		protected override void OnElementPropertyChanged(object sender, PropertyChangedEventArgs e)
		{
			base.OnElementPropertyChanged(sender, e);

			var view = (ImageEntry)Element;

			if (e.PropertyName.Equals(view.FontSize))
				SetFontSize(view);
			if (e.PropertyName.Equals(view.PlaceholderColor))
				SetPlaceholderTextColor(view);
		}

		protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
		{
			base.OnElementChanged(e);

			//run once when element is first initialized
			if (e.OldElement != null || e.NewElement == null)
			{
				return;
			}

			var element = (ImageEntry)this.Element;

			//if there is no image there is no customization
			if (element.Image == ImageEntryImage.None)
			{
				return;
			}

			var textField = this.Control;

			switch (element.ImageAlignment)
			{
				case ImageEntryImageAlignment.Left:
					textField.LeftViewMode = UITextFieldViewMode.Always;
					textField.LeftView = GetImageView(element.ImageUrl);
					break;
				case ImageEntryImageAlignment.Right:
					textField.RightViewMode = UITextFieldViewMode.Always;
					textField.RightView = GetImageView(element.ImageUrl);
					break;
				default:
					throw new ArgumentException(
						$"Unknown option for {typeof(ImageEntryImageAlignment).Name} in {typeof(ImageEntryRenderer).Name}",
						nameof(element.ImageAlignment));
			}

			textField.BorderStyle = UITextBorderStyle.None;
			SetFontSize(element);
			SetPlaceholderTextColor(element);
		}

		private UIView GetImageView(string image)
		{
			var newImgThumb = new UIImageView(GetImage(image));
			newImgThumb.ContentMode = UIViewContentMode.Center;
			return newImgThumb;
		}

		private UIImage GetImage(string imagePath)
		{
			var uiImage = new UIImage(imagePath);
			return uiImage.Scale(new CGSize(this.Control.Font.LineHeight, this.Control.Font.LineHeight));
		}

		void SetFontSize(ImageEntry view)
		{
			if (view.FontSize != Font.Default.FontSize)
				Control.Font = UIFont.SystemFontOfSize((System.nfloat)view.FontSize);
			else if (view.FontSize == Font.Default.FontSize)
				Control.Font = UIFont.SystemFontOfSize(17f);
		}

		void SetPlaceholderTextColor(ImageEntry view)
		{
			if (string.IsNullOrEmpty(view.Placeholder) == false && view.PlaceholderColor != Color.Default)
			{
				var placeholderString = new NSAttributedString(view.Placeholder,
											new UIStringAttributes { ForegroundColor = view.PlaceholderColor.ToUIColor() });
				Control.AttributedPlaceholder = placeholderString;
			}
		}

	}
}
