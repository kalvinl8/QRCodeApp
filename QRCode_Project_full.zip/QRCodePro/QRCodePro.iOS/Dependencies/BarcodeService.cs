﻿using System;
using QRCodePro.Services;
using System.Drawing;
using System.IO;
using Xamarin.Forms;
using UIKit;
using CoreGraphics;
using ZXing.Mobile;
using QRCodePro.iOS.Dependencies;

[assembly: Xamarin.Forms.Dependency(typeof(BarcodeService))]
namespace QRCodePro.iOS.Dependencies
{
	public class BarcodeService : IBarcodeService
	{
		public Stream ConvertImageStream(string text, ZXing.BarcodeFormat format)
		{
			int width = 800;
			int height = 800;

			var barcodeWriter = new ZXing.Mobile.BarcodeWriter
			{
				Format = format,
				Options = new ZXing.Common.EncodingOptions
				{
					Width = width,
					Height = height
				}
			};
			barcodeWriter.Renderer = new ZXing.Mobile.BitmapRenderer();
			var bitmap = barcodeWriter.Write(text);
			var stream = bitmap.AsPNG().AsStream(); // this is the difference 
			stream.Position = 0;

			return stream;
		}
	}
}
