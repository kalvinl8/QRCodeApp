﻿using Prism.Commands;
using Prism.Navigation;
using System.Collections.Generic;
using System.Linq;
using Prism.Services;
using QRCodePro.Helpers;
using Newtonsoft.Json.Linq;
using QRCodePro.Services;
using QRCodePro.Models;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using QRCodePro.Views;
using Xamarin.Forms;
using System;

namespace QRCodePro.ViewModels
{
    public class ViewPostsPageViewModel : BaseViewModel, INavigationAware
    {
        private INavigationService _navigationService;
        private IPageDialogService _dialogService;
        public DataService dataService = new DataService();

        public DelegateCommand OnClickMenu { set; get; }
        public DelegateCommand OnClickCreatePost { get; set; }
        public DelegateCommand OnListRefreshing { get; set; }

        private bool _isRefreshingList = false;
        public bool isRefreshingList
        {
            get { return _isRefreshingList; }
            set { SetProperty(ref _isRefreshingList, value); }
        }

        private bool _hasPosts = true;
        public bool hasPosts
        {
            get { return _hasPosts; }
            set { SetProperty(ref _hasPosts, value); }
        }

        private ObservableCollection<PicturePost> _PostsList = new ObservableCollection<PicturePost>();
        public ObservableCollection<PicturePost> PostsList
        {
            get { return _PostsList; }
            set { SetProperty(ref _PostsList, value); }
        }

        public ViewPostsPageViewModel(INavigationService navigationService, IPageDialogService dialogService)
        {
            _navigationService = navigationService;
            _dialogService = dialogService;

            OnClickMenu = new DelegateCommand(openMenuWindow);
            OnClickCreatePost = new DelegateCommand(NavigateToCreatePost);
            OnListRefreshing = new DelegateCommand(RefreshPostsList);
        }

        private void openMenuWindow()
        {
            RootPage.Instance.IsPresented = true;
        }

        private async void NavigateToCreatePost()
        {
            if (IsBusy) return;
            IsBusy = true;
            await _navigationService.NavigateAsync("CreatePostPage", null, true, true);
            IsBusy = false;
        }

        private async void RefreshPostsList()
        {
            if (IsBusy) return;
            IsBusy = true;
            hasPosts = false;
            isRefreshingList = true;

            PicturePostResponse response = await dataService.getAllPicturePosts();
            if (response != null)
            {
                if (response.status.Equals("success"))
                {
                    PostsList.Clear();
                    List<PicturePost> items = new List<PicturePost>();
                    foreach (PicturePost row in response.data)
                    {
                        DateTime dateValue;
                        if (DateTime.TryParse(row.createdAt.date, out dateValue))
                        {
                            row.time = TimeAgo(dateValue);
                        }
                        else
                        {
                            row.time = "N/A";
                        }
                        System.Diagnostics.Debug.WriteLine("time : " + row.time);
                        items.Add(row);
                    }
                    PostsList = new ObservableCollection<PicturePost>(items);

                    if (PostsList.Count > 0)
                        hasPosts = false;
                    else
                        hasPosts = true;
                }
            }
            else
            {
                hasPosts = true;
                isRefreshingList = false;
                showDialog("Alert!", "You are not connected to internet, please try again later.");
            }
            IsBusy = false;
            isRefreshingList = false;
        }

        public async Task PageChangeAsync(PicturePost item)
        {
            var navigationParams = new NavigationParameters();
            navigationParams.Add("model", item);
            await _navigationService.NavigateAsync("ViewPostDetailPage", navigationParams, true, true);
        }

        public void OnNavigatedFrom(NavigationParameters parameters)
        {
        }

        public void OnNavigatedTo(NavigationParameters parameters)
        {
            RefreshPostsList();
        }

        public void OnNavigatingTo(NavigationParameters parameters)
        {
        }

        public async void showDialog(string title, string msg)
        {
            await _dialogService.DisplayAlertAsync(title, msg, "OK");
        }

        //helper method
        public static string TimeAgo(DateTime dt)
        {
            TimeSpan span = DateTime.Now - dt;
            if (span.Days > 365)
            {
                int years = (span.Days / 365);
                if (span.Days % 365 != 0)
                    years += 1;
                return String.Format("{0} {1} ago",
                years, years == 1 ? "year" : "years");
            }
            if (span.Days > 30)
            {
                int months = (span.Days / 30);
                if (span.Days % 31 != 0)
                    months += 1;
                return String.Format("{0} {1} ago",
                months, months == 1 ? "month" : "months");
            }
            if (span.Days > 0)
                return String.Format("{0} {1} ago",
                span.Days, span.Days == 1 ? "day" : "days");
            if (span.Hours > 0)
                return String.Format("{0} {1} ago",
                span.Hours, span.Hours == 1 ? "hour" : "hours");
            if (span.Minutes > 0)
                return String.Format("{0} {1} ago",
                span.Minutes, span.Minutes == 1 ? "minute" : "minutes");
            if (span.Seconds > 5)
                return String.Format("{0} seconds ago", span.Seconds);
            if (span.Seconds <= 5)
                return "just now";
            return string.Empty;
        }
    }
}
