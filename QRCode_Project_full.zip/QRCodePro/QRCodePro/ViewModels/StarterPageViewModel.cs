﻿using Prism.Commands;
using Prism.Navigation;
using Prism.Services;

namespace QRCodePro.ViewModels
{
    public class StarterPageViewModel : BaseViewModel, INavigationAware
	{
		private INavigationService _navigationService;
		private IPageDialogService _dialogService;

		public DelegateCommand OnClickLogin { get; set; }
		public DelegateCommand OnClickRegister { get; set; }

        public DelegateCommand OnClickGenerateCode { get; set; }
        public DelegateCommand OnClickScanCode { get; set; }

        public StarterPageViewModel(INavigationService navigationService, IPageDialogService dialogService)
		{
			_navigationService = navigationService;
			_dialogService = dialogService;

			OnClickLogin = new DelegateCommand(NavigateToLogin);
			OnClickRegister = new DelegateCommand(NavigateToRegister);

			OnClickGenerateCode = new DelegateCommand(NavigateToGenerateCode);
			OnClickScanCode = new DelegateCommand(NavigateToScanCode);
		}

		private async void NavigateToLogin()
		{
			IsBusy = true;
			await _navigationService.NavigateAsync("LoginPage");
			IsBusy = false;
		}

		private async void NavigateToRegister()
		{
			IsBusy = true;
			await _navigationService.NavigateAsync("RegisterPage");
			IsBusy = false;
		}

		private async void NavigateToGenerateCode()
		{
			IsBusy = true;
			await _navigationService.NavigateAsync("GenerateCodePage");
			IsBusy = false;
		}

		private async void NavigateToScanCode()
		{
			IsBusy = true;
			await _navigationService.NavigateAsync("ScanCodePage");
			IsBusy = false;
		}

		public void OnNavigatedFrom(NavigationParameters parameters)
		{

		}

		public void OnNavigatedTo(NavigationParameters parameters)
		{
		
		}

        public void OnNavigatingTo(NavigationParameters parameters)
        {
            
        }

        private async void showDialog(string title,string msg)
		{
			await _dialogService.DisplayAlertAsync(title, msg, "OK");
		}
    }
}

