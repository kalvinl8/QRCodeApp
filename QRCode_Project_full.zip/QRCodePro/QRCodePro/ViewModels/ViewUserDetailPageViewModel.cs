﻿using System;
using System.IO;
using System.Threading.Tasks;
using Acr.UserDialogs;
using Prism.Commands;
using Prism.Navigation;
using Prism.Services;
using QRCodePro.Models;
using QRCodePro.Services;

namespace QRCodePro.ViewModels
{
    public class ViewUserDetailPageViewModel : BaseViewModel, INavigationAware
    {
        private INavigationService _navigationService;
        private IPageDialogService _dialogService;
        public IDependencyService _dependencyService;
        public DataService dataService = new DataService();

        public DelegateCommand OnClickBack { set; get; }
        public DelegateCommand OnClickFollowUnfollow { get; set; }

        private UserProfile UserDetail { get; set; }

        private string _name = "";
        public string Name
        {
            get { return _name; }
            set { SetProperty(ref _name, value); }
        }
        private string _email = "";
        public string Email
        {
            get { return _email; }
            set { SetProperty(ref _email, value); }
        }
        private string _phone = "";
        public string Phone
        {
            get { return _phone; }
            set { SetProperty(ref _phone, value); }
        }
        private string _profilepic = "";
        public string ProfilePic
        {
            get { return _profilepic; }
            set { SetProperty(ref _profilepic, value); }
        }
        private Xamarin.Forms.ImageSource _QrcodeImage;
        public Xamarin.Forms.ImageSource QrcodeImage
        {
            get { return _QrcodeImage; }
            set { SetProperty(ref _QrcodeImage, value); }
        }
        private string _buisnesname = "";
        public string BuisnesName
        {
            get { return _buisnesname; }
            set { SetProperty(ref _buisnesname, value); }
        }
        private string _buisnesdescription = "";
        public string BuisnesDescription
        {
            get { return _buisnesdescription; }
            set { SetProperty(ref _buisnesdescription, value); }
        }

        private string _followStatus = "Loading...";
        public string FollowStatus
        {
            get { return _followStatus; }
            set { SetProperty(ref _followStatus, value); }
        }

        public ViewUserDetailPageViewModel(INavigationService navigationService,
                                      IPageDialogService dialogService,
                                     IDependencyService dependencyService)
        {
            _navigationService = navigationService;
            _dialogService = dialogService;
            _dependencyService = dependencyService;

            OnClickBack = new DelegateCommand(NavigateBack);
            OnClickFollowUnfollow = new DelegateCommand(ClickedFollowUnfollow);
        }

        private void SetUpInfo()
        {
            if (UserDetail.user_type.Equals("user"))
            {
                BuisnesName = "N/A";
                BuisnesDescription = "N/A";
            }
            else
            {
                BuisnesName = UserDetail.c_name;
                BuisnesDescription = UserDetail.c_address + "/n" + UserDetail.c_website;
            }

            Name = UserDetail.name;
            Email = UserDetail.email;
            Phone = UserDetail.phone;
            ProfilePic = UserDetail.profile_pic;
            LoadQrcodeImage(UserDetail.qrcode_pic);
        }

        private async void NavigateBack()
        {
            IsBusy = true;
            await _navigationService.GoBackAsync();
            IsBusy = false;
        }

        private async void ClickedFollowUnfollow()
        {
            if (IsBusy) return;
            IsBusy = true;

            var dialog = UserDialogs.Instance;
            dialog.ShowLoading("Please wait...", MaskType.Black);
            StatusResponse response = await dataService.FollowUnfollowStatusChange(UserDetail.id);
            if (response != null)
            {
                if (response.status.Equals("failure"))
                {
                    await showDialog("Alert!", "Oops, " + response.message);
                }
                else if (response.status.Equals("success"))
                {
                    dialog.HideLoading();
                    if (FollowStatus.Equals("Follow"))
                        FollowStatus = "Unfollow";
                    else
                        FollowStatus = "Follow";

                    UserDialogs.Instance.Toast("Success.");
                }
                dialog.HideLoading();
            }
            else
            {
                dialog.HideLoading();
                await showDialog("Alert!", "You are not connected to internet, please try again later.");
            }

            IsBusy = false;
        }

        public void OnNavigatedFrom(NavigationParameters parameters)
        {
        }

        public void OnNavigatedTo(NavigationParameters parameters)
        {
            if (parameters.ContainsKey("model"))
            {
                UserDetail = (UserProfile)parameters["model"];
                SetUpInfo();
                CheckFollowUnfollow();
            }
        }

        public void OnNavigatingTo(NavigationParameters parameters)
        {
        }

        public async Task showDialog(string title, string msg)
        {
            await _dialogService.DisplayAlertAsync(title, msg, "OK");
        }

        private async void LoadQrcodeImage(string data)
        {
            var dialog = UserDialogs.Instance;
            dialog.ShowLoading("Please wait...", MaskType.Black);

            var pic = await GenerateBarCode(data.Trim(), ZXing.BarcodeFormat.QR_CODE);
            QrcodeImage = await LoadImageAsync(pic);

            dialog.HideLoading();
        }

        private async Task<Xamarin.Forms.ImageSource> LoadImageAsync(string ImageBase64)
        {
            Task<Xamarin.Forms.ImageSource> result = Task<Xamarin.Forms.ImageSource>.Factory.StartNew(() => Xamarin.Forms.ImageSource.FromStream(
                () => new MemoryStream(Convert.FromBase64String(ImageBase64))));
            return await result;
        }

        private async Task<string> GenerateBarCode(string barcodeText, ZXing.BarcodeFormat format)
        {
            if (_dependencyService.Get<IBarcodeService>() != null)
            {
                var stream = _dependencyService.Get<IBarcodeService>().ConvertImageStream(barcodeText, format);
                return await EncodeImageToBase64(stream);
            }
            else
                return "";
        }

        private async Task<string> EncodeImageToBase64(Stream stream)
        {
            var bytes = new byte[stream.Length];
            await stream.ReadAsync(bytes, 0, (int)stream.Length);
            return System.Convert.ToBase64String(bytes);
        }

        private async void CheckFollowUnfollow()
        {
            if (IsBusy) return;
            IsBusy = true;

            var dialog = UserDialogs.Instance;
            dialog.ShowLoading("Please wait...", MaskType.Black);
            StatusResponse response = await dataService.CheckIsFollowing(UserDetail.id);
            if (response != null)
            {
                if (response.status.Equals("failure"))
                {
                    await showDialog("Alert!", "Oops, " + response.message);
                }
                else if (response.status.Equals("success"))
                {
                    dialog.HideLoading();
                    if (response.message.Equals("true"))
                    {
                        FollowStatus = "Unfollow";
                    }
                    else
                    {
                        FollowStatus = "Follow";
                    }
                }
                dialog.HideLoading();
            }
            else
            {
                dialog.HideLoading();
                await showDialog("Alert!", "You are not connected to internet, please try again later.");
            }

            IsBusy = false;
        }

    }
}
