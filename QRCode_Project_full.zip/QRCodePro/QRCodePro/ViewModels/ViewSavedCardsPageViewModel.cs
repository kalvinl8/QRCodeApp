﻿using Prism.Commands;
using Prism.Navigation;
using System.Collections.Generic;
using Prism.Services;
using QRCodePro.Services;
using QRCodePro.Models;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using QRCodePro.Views;
using System;
using System.IO;

namespace QRCodePro.ViewModels
{
    public class ViewSavedCardsPageViewModel : BaseViewModel, INavigationAware
    {
        private INavigationService _navigationService;
        private IPageDialogService _dialogService;
        public IDependencyService _dependencyService;
        public DataService dataService = new DataService();

        public DelegateCommand OnClickMenu { set; get; }
        public DelegateCommand OnListRefreshing { get; set; }

        private bool _isRefreshingList = false;
        public bool isRefreshingList
        {
            get { return _isRefreshingList; }
            set { SetProperty(ref _isRefreshingList, value); }
        }

        private bool _hasPosts = true;
        public bool hasPosts
        {
            get { return _hasPosts; }
            set { SetProperty(ref _hasPosts, value); }
        }

        private ObservableCollection<BuisnessCard> _cardsList = new ObservableCollection<BuisnessCard>();
        public ObservableCollection<BuisnessCard> CardsList
        {
            get { return _cardsList; }
            set { SetProperty(ref _cardsList, value); }
        }


		public ViewSavedCardsPageViewModel(INavigationService navigationService,
									  IPageDialogService dialogService,
									 IDependencyService dependencyService)
		{
			_navigationService = navigationService;
			_dialogService = dialogService;
			_dependencyService = dependencyService;

            OnClickMenu = new DelegateCommand(openMenuWindow);
            OnListRefreshing = new DelegateCommand(RefreshPostsList);
        }

        private void openMenuWindow()
        {
            RootPage.Instance.IsPresented = true;
        }

        private async void RefreshPostsList()
        {
			if (IsBusy) return;
			IsBusy = true;
            IsBusy = true;
            hasPosts = false;
            isRefreshingList = true;

            SavedCardsResponse response = await dataService.getAllSavedCards();
            if (response != null)
            {
                if (response.status.Equals("success"))
                {
                    CardsList.Clear();
                    List<BuisnessCard> items = new List<BuisnessCard>();
                    foreach (BuisnessCard row in response.data)
                    {
                        DateTime dateValue;
                        if (DateTime.TryParse(row.createdAt.date, out dateValue))
                        {
                            row.time = TimeAgo(dateValue);
                        }
                        else
                        {
                            row.time = "N/A";
                        }
                        System.Diagnostics.Debug.WriteLine("time : " + row.time);

                        var pic = await GenerateBarCode(row.data, ZXing.BarcodeFormat.QR_CODE);
                        row.qrcodeimage = await LoadImageAsync(pic);

                        items.Add(row);
                    }
                    CardsList = new ObservableCollection<BuisnessCard>(items);

                    if (CardsList.Count > 0)
                        hasPosts = false;
                    else
                        hasPosts = true;
                }
            }
            else
            {
                hasPosts = true;
                isRefreshingList = false;
                showDialog("Alert!", "You are not connected to internet, please try again later.");
            }
            IsBusy = false;
            isRefreshingList = false;
        }

        public async Task PageChangeAsync(BuisnessCard item)
        {
            var navigationParams = new NavigationParameters();
            navigationParams.Add("model", item);
            navigationParams.Add("FromProfile", true);
            await _navigationService.NavigateAsync("ViewCodeDetailPage", navigationParams, true, true);
        }

        public void OnNavigatedFrom(NavigationParameters parameters)
        {
        }

        public void OnNavigatedTo(NavigationParameters parameters)
        {
            RefreshPostsList();
        }

        public void OnNavigatingTo(NavigationParameters parameters)
        {
        }

        public async void showDialog(string title, string msg)
        {
            await _dialogService.DisplayAlertAsync(title, msg, "OK");
        }

        //helper method
        public static string TimeAgo(DateTime dt)
        {
            TimeSpan span = DateTime.Now - dt;
            if (span.Days > 365)
            {
                int years = (span.Days / 365);
                if (span.Days % 365 != 0)
                    years += 1;
                return String.Format("{0} {1} ago",
                years, years == 1 ? "year" : "years");
            }
            if (span.Days > 30)
            {
                int months = (span.Days / 30);
                if (span.Days % 31 != 0)
                    months += 1;
                return String.Format("{0} {1} ago",
                months, months == 1 ? "month" : "months");
            }
            if (span.Days > 0)
                return String.Format("{0} {1} ago",
                span.Days, span.Days == 1 ? "day" : "days");
            if (span.Hours > 0)
                return String.Format("{0} {1} ago",
                span.Hours, span.Hours == 1 ? "hour" : "hours");
            if (span.Minutes > 0)
                return String.Format("{0} {1} ago",
                span.Minutes, span.Minutes == 1 ? "minute" : "minutes");
            if (span.Seconds > 5)
                return String.Format("{0} seconds ago", span.Seconds);
            if (span.Seconds <= 5)
                return "just now";
            return string.Empty;
        }

        private async Task<Xamarin.Forms.ImageSource> LoadImageAsync(string ImageBase64)
        {
            Task<Xamarin.Forms.ImageSource> result = Task<Xamarin.Forms.ImageSource>.Factory.StartNew(() => Xamarin.Forms.ImageSource.FromStream(
                () => new MemoryStream(Convert.FromBase64String(ImageBase64))));
            return await result;
        }

        private async Task<string> GenerateBarCode(string barcodeText, ZXing.BarcodeFormat format)
        {
            if (_dependencyService.Get<IBarcodeService>() != null)
            {
                var stream = _dependencyService.Get<IBarcodeService>().ConvertImageStream(barcodeText, format);
                return await EncodeImageToBase64(stream);
            }
            else
                return "";
        }

        private async Task<string> EncodeImageToBase64(Stream stream)
        {
            var bytes = new byte[stream.Length];
            await stream.ReadAsync(bytes, 0, (int)stream.Length);
            return System.Convert.ToBase64String(bytes);
        }

    }
}
