﻿using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Linq;
using Prism.Services;
using Acr.UserDialogs;
using QRCodePro.Helpers;
using Newtonsoft.Json.Linq;
using QRCodePro.Services;
using System.Diagnostics;
using QRCodePro.Models;

namespace QRCodePro.ViewModels
{
    public class RegisterPageViewModel : BaseViewModel, INavigationAware
    {
        private INavigationService _navigationService;
        private IPageDialogService _dialogService;
        private DataService dataService = new DataService();


        private bool _isUserSelected = false;
        public bool IsUserSelected
        {
            get { return _isUserSelected; }
            set { SetProperty(ref _isUserSelected, value); }
        }
        private bool _isBuisnessSelected = false;
        public bool IsBuisnessSelected
        {
            get { return _isBuisnessSelected; }
            set { SetProperty(ref _isBuisnessSelected, value); }
        }

        private string _userType;
        public string UserType
        {
            get { return _userType; }
            set { SetProperty(ref _userType, value); }
        }

        private int _SelectedIndex;
        public int SelectedIndex
        {
            get { return _SelectedIndex; }
            set { SetProperty(ref _SelectedIndex, value); }
        }

        private string _name = "";
        public string Name
        {
            get { return _name; }
            set { SetProperty(ref _name, value); }
        }

        private string _email = "";
        public string Email
        {
            get { return _email; }
            set { SetProperty(ref _email, value); }
        }

        private string _password = "";
        public string Password
        {
            get { return _password; }
            set { SetProperty(ref _password, value); }
        }

        private string _phone = "";
        public string Phone
        {
            get { return _phone; }
            set { SetProperty(ref _phone, value); }
        }

        private string _companyName = "";
        public string CompanyName
        {
            get { return _companyName; }
            set { SetProperty(ref _companyName, value); }
        }

        private string _companyAdd = "";
        public string CompanyAddress
        {
            get { return _companyAdd; }
            set { SetProperty(ref _companyAdd, value); }
        }

        private string _companyWeb = "";
        public string CompanyWebsite
        {
            get { return _companyWeb; }
            set { SetProperty(ref _companyWeb, value); }
        }

        public DelegateCommand OnClickRegister { get; set; }
        public DelegateCommand OnClickBack { get; set; }

        public RegisterPageViewModel(INavigationService navigationService, IPageDialogService dialogService)
        {
            _navigationService = navigationService;
            _dialogService = dialogService;

            OnClickRegister = new DelegateCommand(AttemptRegister);
            OnClickBack = new DelegateCommand(NavigateBack);
        }

        public void ToggleViewPannel()
        {
            switch (SelectedIndex)
            {
                case 0:
                    IsUserSelected = true;
                    IsBuisnessSelected = false;
                    break;
                case 1:
                    IsUserSelected = false;
                    IsBuisnessSelected = true;
                    break;
            }
        }

        private async void AttemptRegister()
        {
            IsBusy = true;
            if (Email.Length == 0 || !Email.Contains("@") ||
                Name.Length == 0 ||
                Phone.Length == 0 ||
                Password.Length == 0)
            {
                showDialog("Alert!", "Please enter valid info first.");
            }
            else
            {
                var dialog = UserDialogs.Instance;
                dialog.ShowLoading("Please wait...", MaskType.Black);
                string type = "user";
                if (IsBuisnessSelected)
                    type = "buisness";

                AccountResponse response = await dataService.Register(Name, (string)Email.ToLower(), Password, Phone,
                                                              type, CompanyName, CompanyAddress, CompanyWebsite);
                if (response != null)
                {
                    if (response.status.Equals("failure"))
                    {
                        showDialog("Alert!", "Oops, " + response.message);
                    }
                    else if (response.status.Equals("success"))
                    {
                        if (response.data != null)
                        {
                            Settings.IsLoggedIn = true;
                            Settings.UserId = response.data.id;
                            Settings.UserName = response.data.name;
                            Settings.UserEmail = response.data.email;
                            Settings.UserPhone = response.data.phone;
                            Settings.UserType = response.data.user_type;
                            Settings.UserProfilePic = response.data.profile_pic;
                            Settings.UserQRCodePic = response.data.qrcode_pic;
                            Settings.CompanyName = response.data.c_name;
                            Settings.CompanyAddress = response.data.c_address;
                            Settings.CompanyWebsite = response.data.c_website;

                            dialog.HideLoading();
                            await _navigationService.NavigateAsync("RootPage/NavigationPage/DashboardPage");
                        }
                    }
                    dialog.HideLoading();
                }
                else
                {
                    dialog.HideLoading();
                    showDialog("Alert!", "You are not connected to internet, please try again later.");
                }
                IsBusy = false;
            }
        }

        private async void NavigateBack()
        {
            IsBusy = true;
            await _navigationService.GoBackAsync();
            IsBusy = false;
        }

        public void OnNavigatedFrom(NavigationParameters parameters)
        {

        }

        public void OnNavigatedTo(NavigationParameters parameters)
        {

        }

        public void OnNavigatingTo(NavigationParameters parameters)
        {

        }

        private async void showDialog(string title, string msg)
        {
            await _dialogService.DisplayAlertAsync(title, msg, "OK");
        }
    }
}

