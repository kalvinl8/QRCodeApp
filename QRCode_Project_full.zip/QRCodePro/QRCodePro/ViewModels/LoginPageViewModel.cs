﻿using Prism.Commands;
using Prism.Navigation;
using Prism.Services;
using Acr.UserDialogs;
using QRCodePro.Helpers;
using QRCodePro.Services;
using QRCodePro.Models;

namespace QRCodePro.ViewModels
{
    public class LoginPageViewModel : BaseViewModel, INavigationAware
    {
        private INavigationService _navigationService;
        private IPageDialogService _dialogService;
        private DataService dataService = new DataService();

        private string _email = "";
        public string Email
        {
            get { return _email; }
            set { SetProperty(ref _email, value); }
        }

        private string _password = "";
        public string Password
        {
            get { return _password; }
            set { SetProperty(ref _password, value); }
        }

        public DelegateCommand OnClickLogin { get; set; }
        public DelegateCommand OnClickBack { get; set; }

        public LoginPageViewModel(INavigationService navigationService, IPageDialogService dialogService)
        {
            _navigationService = navigationService;
            _dialogService = dialogService;

            OnClickLogin = new DelegateCommand(AttemptLogin);
            OnClickBack = new DelegateCommand(NavigateBack);
        }

        private async void AttemptLogin()
        {
            if (IsBusy) return;
            IsBusy = true;
            if (Email.Length == 0 || !Email.Contains("@") || Password.Length == 0)
            {
                showDialog("Alert!", "Please enter email and password first.");
            }
            else
            {
                var dialog = UserDialogs.Instance;
                dialog.ShowLoading("Please wait...", MaskType.Black);
                AccountResponse response = await dataService.Login((string)Email.ToLower(), Password);
                if (response != null)
                {
                    if (response.status.Equals("failure"))
                    {
                        showDialog("Alert!", "Oops, " + response.message);
                    }
                    else if (response.status.Equals("success"))
                    {
                        if (response.data != null)
                        {
                            Settings.IsLoggedIn = true;
                            Settings.UserId = response.data.id;
                            Settings.UserName = response.data.name;
                            Settings.UserEmail = response.data.email;
                            Settings.UserPhone = response.data.phone;
                            Settings.UserType = response.data.user_type;
                            Settings.UserProfilePic = response.data.profile_pic;
                            Settings.UserQRCodePic = response.data.qrcode_pic;
                            Settings.CompanyName = response.data.c_name;
                            Settings.CompanyAddress = response.data.c_address;
                            Settings.CompanyWebsite = response.data.c_website;

                            dialog.HideLoading();
                            await _navigationService.NavigateAsync("RootPage/NavigationPage/DashboardPage");
                        }
                    }
                    dialog.HideLoading();
                }
                else
                {
                    dialog.HideLoading();
                    showDialog("Alert!", "You are not connected to internet, please try again later.");
                }
            }
            IsBusy = false;
        }

        private async void NavigateBack()
        {
            IsBusy = true;
            await _navigationService.GoBackAsync();
            IsBusy = false;
        }

        public void OnNavigatedFrom(NavigationParameters parameters)
        {

        }

        public void OnNavigatedTo(NavigationParameters parameters)
        {

        }

        public void OnNavigatingTo(NavigationParameters parameters)
        {

        }

        private async void showDialog(string title, string msg)
        {
            await _dialogService.DisplayAlertAsync(title, msg, "OK");
        }
    }
}

