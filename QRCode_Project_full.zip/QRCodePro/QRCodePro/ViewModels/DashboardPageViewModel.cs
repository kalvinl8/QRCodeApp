﻿using System;
using System.Threading.Tasks;
using Prism.Commands;
using Prism.Navigation;
using Prism.Services;
using QRCodePro.Services;
using QRCodePro.Views;

namespace QRCodePro.ViewModels
{
    public class DashboardPageViewModel : BaseViewModel, INavigationAware
    {
		private INavigationService _navigationService;
		private IPageDialogService _dialogService;
		public DataService dataService = new DataService();

		public DelegateCommand OnClickMenu { set; get; }
		public DelegateCommand OnClickGenerateCode { get; set; }
		public DelegateCommand OnClickScanCode { get; set; }

		public DashboardPageViewModel(INavigationService navigationService, IPageDialogService dialogService)
		{
			_navigationService = navigationService;
			_dialogService = dialogService;

			OnClickMenu = new DelegateCommand(openMenuWindow);
			OnClickGenerateCode = new DelegateCommand(NavigateToGenerateCode);
			OnClickScanCode = new DelegateCommand(NavigateToScanCode);
		}

		private void openMenuWindow()
		{
			RootPage.Instance.IsPresented = true;
		}

		private async void NavigateToGenerateCode()
		{
			IsBusy = true;
			await _navigationService.NavigateAsync("GenerateCodePage");
			IsBusy = false;
		}

		private async void NavigateToScanCode()
		{
			IsBusy = true;
			await _navigationService.NavigateAsync("ScanCodePage");
			IsBusy = false;
		}

		public void OnNavigatedFrom(NavigationParameters parameters)
		{
		}

		public void OnNavigatedTo(NavigationParameters parameters)
		{
		}

		public void OnNavigatingTo(NavigationParameters parameters)
		{
		}

		public async Task showDialog(string title, string msg)
		{
            await _dialogService.DisplayAlertAsync(title, msg, "OK");
		}
    }
}
