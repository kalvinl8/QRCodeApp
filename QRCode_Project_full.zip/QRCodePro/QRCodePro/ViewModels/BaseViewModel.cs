﻿using Prism.Mvvm;

namespace QRCodePro.ViewModels
{
	public abstract class BaseViewModel : BindableBase
	{
		private bool _isBusy = false;
		public bool IsBusy
		{
			get { return _isBusy; }
			set { SetProperty(ref _isBusy, value); }
		}
	}
}
