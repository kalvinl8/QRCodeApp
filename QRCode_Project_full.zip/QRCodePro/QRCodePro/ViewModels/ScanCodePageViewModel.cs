﻿using Prism.Commands;
using Prism.Navigation;
using Prism.Services;
using QRCodePro.Services;
using Xamarin.Forms;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System;
using QRCodePro.Helpers;

namespace QRCodePro.ViewModels
{
    public class ScanCodePageViewModel : BaseViewModel, INavigationAware
    {
        private INavigationService _navigationService;
        private IPageDialogService _dialogService;
        private DataService dataService = new DataService();

        public DelegateCommand OnClickBack { get; set; }
        public DelegateCommand ClickedSaveInProfile { set; get; }
        public DelegateCommand ClickedUrlLink { set; get; }

        private bool _isLoggedIn = Settings.IsLoggedIn;
        public bool IsLoggedIn
        {
            get { return _isLoggedIn; }
            set { SetProperty(ref _isLoggedIn, value); }
        }

        private bool _isBuisnessCard = false;
        public bool IsBuisnessCard
        {
            get { return _isBuisnessCard; }
            set { SetProperty(ref _isBuisnessCard, value); }
        }

        private bool _isWebUrl = false;
        public bool IsWebUrl
        {
            get { return _isWebUrl; }
            set { SetProperty(ref _isWebUrl, value); }
        }

        private string _url = "";
        public string Url
        {
            get { return _url; }
            set { SetProperty(ref _url, value); }
        }

        private string _personName = "";
        public string PersonName
        {
            get { return _personName; }
            set { SetProperty(ref _personName, value); }
        }
        private string _companyName = "";
        public string CompanyName
        {
            get { return _companyName; }
            set { SetProperty(ref _companyName, value); }
        }
        private string _phoneNo = "";
        public string PhoneNo
        {
            get { return _phoneNo; }
            set { SetProperty(ref _phoneNo, value); }
        }
        private string _faxNo = "";
        public string FaxNo
        {
            get { return _faxNo; }
            set { SetProperty(ref _faxNo, value); }
        }
        private string _website = "";
        public string Website
        {
            get { return _website; }
            set { SetProperty(ref _website, value); }
        }
        private string _address = "";
        public string Address
        {
            get { return _address; }
            set { SetProperty(ref _address, value); }
        }

        public ScanCodePageViewModel(INavigationService navigationService,
                                     IPageDialogService dialogService)
        {
            _navigationService = navigationService;
            _dialogService = dialogService;

            OnClickBack = new DelegateCommand(NavigateBack);
            ClickedSaveInProfile = new DelegateCommand(SaveInProfileClicked);
            ClickedUrlLink = new DelegateCommand(WebUrlClicked);
        }

        private void WebUrlClicked()
        {
            if (IsBusy)
                return;

            IsBusy = true;
            Device.OpenUri(new Uri(Url));
            IsBusy = false;
        }

        private async void NavigateBack()
        {
            if (IsBusy)
                return;

            IsBusy = true;
            await _navigationService.GoBackAsync();
            IsBusy = false;
        }

        private async void SaveInProfileClicked()
        {
            if (IsBusy)
                return;

            IsBusy = true;
            await _navigationService.GoBackAsync();
            IsBusy = false;
        }

        public void OnNavigatedFrom(NavigationParameters parameters)
        {

        }

        public void OnNavigatedTo(NavigationParameters parameters)
        {

        }

        public void OnNavigatingTo(NavigationParameters parameters)
        {

        }

        public async Task showDialog(string title, string msg)
        {
            await _dialogService.DisplayAlertAsync(title, msg, "OK");
        }

        public void DecodeQRCode(dynamic code)
        {
            if (code == null)
                return;

            string type = (string)code["format"].Value.ToString();
            if (type.Equals("card"))
            {
                if (code["data"] is JObject)
                {
                    JObject dataObj = (JObject)code["data"];
                    PersonName = (string)dataObj["p_name"].ToString();
                    CompanyName = (string)dataObj["c_name"].ToString();
                    PhoneNo = (string)dataObj["phone"].ToString();
                    FaxNo = (string)dataObj["fax"].ToString();
                    Address = (string)dataObj["address"].ToString();
                    Website = (string)dataObj["website"].ToString();

                    IsBuisnessCard = true;
                }
            }
            else if (type.Equals("url"))
            {
                if (code["data"] is JObject)
                {
                    JObject dataObj = (JObject)code["data"];
                    Url = (string)dataObj["url"].ToString();
                    if (!Url.Contains("http"))
                    {
                        Url = "http://" + Url;
                    }
                    Device.OpenUri(new Uri(Url));
                    IsWebUrl = true;
                }
            }
        }

    }
}

