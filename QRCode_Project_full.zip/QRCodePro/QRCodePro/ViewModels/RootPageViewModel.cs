﻿using QRCodePro.Models;
using Prism.Mvvm;
using Prism.Navigation;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using Acr.UserDialogs;
using QRCodePro.Services;

namespace QRCodePro.ViewModels
{
	public class RootPageViewModel : BindableBase
	{
		INavigationService _navigationService;
		public DataService dataService = new DataService();

		private bool isPresented;
		public bool IsPresented
		{
			get { return isPresented; }
			set { SetProperty(ref isPresented, value); }
		}

		public ObservableCollection<MenuCellModel> MenuList { get; } = new ObservableCollection<MenuCellModel>
		{
				new MenuCellModel { MenuTitle = "QR Code Home", logo = "img_home.png"},
                new MenuCellModel { MenuTitle = "View All Posts", logo = "img_posts.png"},
                new MenuCellModel { MenuTitle = "My Profile", logo = "img_profile.png"},
				new MenuCellModel { MenuTitle = "Saved Buisness Cards", logo = "img_cards.png"},
				new MenuCellModel { MenuTitle = "Logout", logo = "img_logout.png"}
		};

		public RootPageViewModel(INavigationService navigationService)
		{
			_navigationService = navigationService;
		}

		public async Task PageChangeAsync(MenuCellModel item)
		{
			IsPresented = false;

			if (item.MenuTitle.Equals("QR Code Home"))
			{
				UserDialogs.Instance.ShowLoading("Please wait...", MaskType.Black);
				await _navigationService.NavigateAsync("NavigationPage/DashboardPage");
				UserDialogs.Instance.HideLoading();
			}
			else if (item.MenuTitle.Equals("View All Posts"))
			{
				UserDialogs.Instance.ShowLoading("Please wait...", MaskType.Black);
				await _navigationService.NavigateAsync("NavigationPage/ViewPostsPage");
				UserDialogs.Instance.HideLoading();
			}
			else if (item.MenuTitle.Equals("My Profile"))
			{
				UserDialogs.Instance.ShowLoading("Please wait...", MaskType.Black);
				await _navigationService.NavigateAsync("NavigationPage/ProfileViewPage");
				UserDialogs.Instance.HideLoading();
			}
			else if (item.MenuTitle.Equals("Saved Buisness Cards"))
			{
				UserDialogs.Instance.ShowLoading("Please wait...", MaskType.Black);
				await _navigationService.NavigateAsync("NavigationPage/ViewSavedCardsPage");
				UserDialogs.Instance.HideLoading();
			}
			else if (item.MenuTitle.Equals("Logout"))
			{
				var result = await UserDialogs.Instance.ConfirmAsync("Are you sure you want to Logout?", "Alert!", "Yes", "No");
				if (result)
				{
					//clear session and logout user
					//Settings.IsLoggedIn = false;
					//await _navigationService.NavigateAsync("app:///LoginPage", null, true, true);
                    App.Instance.Logout();
				}
			}
		}
	}
}
