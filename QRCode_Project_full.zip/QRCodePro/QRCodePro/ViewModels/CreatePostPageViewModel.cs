﻿using Prism.Commands;
using Prism.Navigation;
using Prism.Services;
using Acr.UserDialogs;
using QRCodePro.Helpers;
using QRCodePro.Services;
using QRCodePro.Models;
using System.Threading.Tasks;
using System.IO;
using Xamarin.Forms;
using Plugin.Media;
using Plugin.Media.Abstractions;

namespace QRCodePro.ViewModels
{
    public class CreatePostPageViewModel : BaseViewModel, INavigationAware
    {
        private INavigationService _navigationService;
        private IPageDialogService _dialogService;
        private DataService dataService = new DataService();

        private string _description = "";
        public string Description
        {
            get { return _description; }
            set { SetProperty(ref _description, value); }
        }

        private string _picture = "";
        public string Picture
        {
            get { return _picture; }
            set { SetProperty(ref _picture, value); }
        }

        private Xamarin.Forms.ImageSource _postedPicture = Xamarin.Forms.ImageSource.FromFile("img_na_placeholder.png");
		public Xamarin.Forms.ImageSource PostedPicture
		{
			get { return _postedPicture; }
			set { SetProperty(ref _postedPicture, value); }
		}

        public DelegateCommand OnClickPost { get; set; }
        public DelegateCommand OnClickBack { get; set; }

        public CreatePostPageViewModel(INavigationService navigationService, IPageDialogService dialogService)
        {
            _navigationService = navigationService;
            _dialogService = dialogService;

            OnClickPost = new DelegateCommand(AttemptCreatePost);
            OnClickBack = new DelegateCommand(NavigateBack);
		}

		private async void NavigateBack()
		{
            if (IsBusy) return;
			IsBusy = true;
			await _navigationService.GoBackAsync();
			IsBusy = false;
		}

        public async Task TakeImageFromGallery()
		{
            if (IsBusy) return;
			IsBusy = true;

			Device.BeginInvokeOnMainThread(async () =>
			{
				if (!await CrossMedia.Current.Initialize())
				{
                    await showDialog("Alert!","Your device seems inappropriate for media. Try this on different device.");
					return;
				}

				if (!CrossMedia.Current.IsPickPhotoSupported)
				{
					await showDialog("Alert!", "Your device seems inappropriate for media. Try this on different device.");
					return;
				}

				var file = await CrossMedia.Current.PickPhotoAsync(new PickMediaOptions
				{
					CompressionQuality = 20,
					PhotoSize = PhotoSize.Small
				});

				if (file == null)
					return;

				var memoryStream = new MemoryStream();
				await file.GetStream().CopyToAsync(memoryStream);
				byte[] imageAsByte = memoryStream.ToArray();

                Picture = System.Convert.ToBase64String(imageAsByte);
				await LoadImageAsync(imageAsByte);
                file.Dispose();
			});

			IsBusy = false;
		}

        public async Task TakeImageFromCamera()
		{
			if (IsBusy) return;
			IsBusy = true;

			Device.BeginInvokeOnMainThread(async () =>
			{
				if (!await CrossMedia.Current.Initialize())
				{
					await showDialog("Alert!", "Your device seems inappropriate for media. Try this on different device.");
					return;
				}

                if (!CrossMedia.Current.IsTakePhotoSupported)
				{
					await showDialog("Alert!", "Your device seems inappropriate for media. Try this on different device.");
					return;
				}

				var file = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions
				{
					CompressionQuality = 35,
					PhotoSize = PhotoSize.Custom,
					CustomPhotoSize = 10
				});

				if (file == null)
					return;

				var memoryStream = new MemoryStream();
				await file.GetStream().CopyToAsync(memoryStream);
				byte[] imageAsByte = memoryStream.ToArray();

				Picture = System.Convert.ToBase64String(imageAsByte);
				await LoadImageAsync(imageAsByte);
                file.Dispose();
			});

			IsBusy = false;
		}

        private async void AttemptCreatePost()
        {
            if (IsBusy) return;
            IsBusy = true;
            if (Description.Length == 0 || Picture.Length == 0)
            {
                await showDialog("Alert!", "Please fill out all of information before submitting.");
            }
            else
            {
                var dialog = UserDialogs.Instance;
                dialog.ShowLoading("Posting, Please wait...", MaskType.Black);
                PicturePostResponse response = await dataService.CreateNewPicturePost(Description, Picture);
                if (response != null)
                {
                    if (response.status.Equals("failure"))
                    {
                        await showDialog("Alert!", "Oops, " + response.message);
                    }
                    else if (response.status.Equals("success"))
                    {
                        dialog.HideLoading();
                        UserDialogs.Instance.Toast("Post has been created successfully.");
                        await _navigationService.GoBackAsync();
                    }
                    dialog.HideLoading();
                }
                else
                {
                    dialog.HideLoading();
                    await showDialog("Alert!", "You are not connected to internet, please try again later.");
                }
            }
            IsBusy = false;
        }

        public void OnNavigatedFrom(NavigationParameters parameters)
        {

        }

        public void OnNavigatedTo(NavigationParameters parameters)
        {

        }

        public void OnNavigatingTo(NavigationParameters parameters)
        {

        }

        private async Task showDialog(string title, string msg)
        {
            await _dialogService.DisplayAlertAsync(title, msg, "OK");
        }

		private async Task LoadImageAsync(byte[] imgArray)
		{
			Task<Xamarin.Forms.ImageSource> result = Task<Xamarin.Forms.ImageSource>.Factory.StartNew(() => Xamarin.Forms.ImageSource.FromStream(
				() => new MemoryStream(imgArray)));
            PostedPicture = await result;
		}
    }
}

