﻿using Prism.Commands;
using Prism.Navigation;
using Prism.Services;
using QRCodePro.Services;
using Xamarin.Forms;
using System.Threading.Tasks;
using QRCodePro.Models;
using Tesseract;
using XLabs.Platform.Device;
using XLabs.Ioc;
using Plugin.Media;
using Plugin.Media.Abstractions;
using System.IO;
using Acr.UserDialogs;

namespace QRCodePro.ViewModels
{
    public class GenerateCodePageViewModel : BaseViewModel, INavigationAware
    {
        private INavigationService _navigationService;
        private IPageDialogService _dialogService;
        private DataService dataService = new DataService();

        public DelegateCommand OnClickBack { get; set; }
        public DelegateCommand webBarCommand { set; get; }
        public DelegateCommand buisnessBarCommand { set; get; }

        public DelegateCommand ClickedBuisnessCardGenerate { set; get; }
        public DelegateCommand ClickedWebCardGenerate { set; get; }

        private readonly ITesseractApi _tesseractApi;
        private readonly IDevice _device;

        private string _url = "";
        public string Url
        {
            get { return _url; }
            set { SetProperty(ref _url, value); }
        }

        private string _personName = "";
        public string PersonName
        {
            get { return _personName; }
            set { SetProperty(ref _personName, value); }
        }
        private string _companyName = "";
        public string CompanyName
        {
            get { return _companyName; }
            set { SetProperty(ref _companyName, value); }
        }
        private string _phoneNo = "";
        public string PhoneNo
        {
            get { return _phoneNo; }
            set { SetProperty(ref _phoneNo, value); }
        }
        private string _faxNo = "";
        public string FaxNo
        {
            get { return _faxNo; }
            set { SetProperty(ref _faxNo, value); }
        }
        private string _website = "";
        public string Website
        {
            get { return _website; }
            set { SetProperty(ref _website, value); }
        }
        private string _address = "";
        public string Address
        {
            get { return _address; }
            set { SetProperty(ref _address, value); }
        }

        public GenerateCodePageViewModel(INavigationService navigationService, IPageDialogService dialogService)
        {
            _navigationService = navigationService;
            _dialogService = dialogService;

            OnClickBack = new DelegateCommand(NavigateBack);
            buisnessBarCommand = new DelegateCommand(BuisnessCommandSelected);
            webBarCommand = new DelegateCommand(WebCommandSelected);

            ClickedBuisnessCardGenerate = new DelegateCommand(GenerateBuisnessCard);
            ClickedWebCardGenerate = new DelegateCommand(GenerateWebCard);

            _tesseractApi = Resolver.Resolve<ITesseractApi>();
            _device = Resolver.Resolve<IDevice>();
        }

        private async void GenerateBuisnessCard()
        {
            if (IsBusy)
                return;

            IsBusy = true;
            if (PersonName.Length != 0 &&
                CompanyName.Length != 0 &&
                PhoneNo.Length != 0 &&
                FaxNo.Length != 0 &&
                Website.Length != 0 &&
                Address.Length != 0)
            {
                string data = "{ \"format\":\"card\" , \"data\":{\"p_name\":\"" + PersonName + "\",\"c_name\":\"" + CompanyName + "\",\"phone\":\"" + PhoneNo + "\",\"fax\":\"" + FaxNo + "\",\"address\":\"" + Address + "\",\"website\":\"" + Website + "\"} }";
                BuisnessCard cardData = new BuisnessCard();
                cardData.data = data;
                var navigationParams = new NavigationParameters();
                navigationParams.Add("model", cardData);
                await _navigationService.NavigateAsync("ViewCodeDetailPage", navigationParams, true, true);
            }
            else
            {
                await showDialog("Alert!", "Please enter valid information.");
            }
            IsBusy = false;
        }

        private async void GenerateWebCard()
        {
            if (IsBusy)
                return;

            IsBusy = true;
            if (Url.Length != 0)
            {
                string data = "{ \"format\":\"url\" , \"data\":{\"url\":\"" + Url + "\"} }";
                BuisnessCard cardData = new BuisnessCard();
                cardData.data = data;
                var navigationParams = new NavigationParameters();
                navigationParams.Add("model", cardData);
                await _navigationService.NavigateAsync("ViewCodeDetailPage", navigationParams, true, true);
            }
            else
            {
                await showDialog("Alert!", "Please enter valid web address.");
            }
            IsBusy = false;
        }

        public async Task ScanBuisnessCardFromGallery()
        {
            if (IsBusy)
                return;

            IsBusy = true;

            Device.BeginInvokeOnMainThread(async () =>
            {
                if (!await CrossMedia.Current.Initialize())
                {
                    await showDialog("Alert!", "Your device seems inappropriate for media. Try this on different device.");
                    return;
                }

                if (!CrossMedia.Current.IsPickPhotoSupported)
                {
                    await showDialog("Alert!", "Your device seems inappropriate for media. Try this on different device.");
                    return;
                }

                if (!_tesseractApi.Initialized)
                    await _tesseractApi.Init("eng");

                var file = await CrossMedia.Current.PickPhotoAsync(new PickMediaOptions
                {
                    CompressionQuality = 20,
                    PhotoSize = PhotoSize.Small
                });

                if (file == null)
                    return;

                //start loader and start reading
                var dialog = UserDialogs.Instance;
                dialog.ShowLoading("Working, Please wait...", MaskType.Black);

                var memoryStream = new MemoryStream();
                await file.GetStream().CopyToAsync(memoryStream);
                byte[] imageAsByte = memoryStream.ToArray();

                var tessResult = await _tesseractApi.SetImage(imageAsByte);
                if (tessResult)
                {
                    var scannedText = _tesseractApi.Text;
                    System.Diagnostics.Debug.WriteLine("scanned : " + scannedText);
                    await ParsScannedText(scannedText);
                }

                file.Dispose();
                dialog.HideLoading();
            });

            IsBusy = false;
        }

        public async Task ScanBuisnessCardFromCamera()
        {
            if (IsBusy)
                return;

            IsBusy = true;

            Device.BeginInvokeOnMainThread(async () =>
            {
                if (!await CrossMedia.Current.Initialize())
                {
                    await showDialog("Alert!", "Your device seems inappropriate for media. Try this on different device.");
                    return;
                }

                if (!CrossMedia.Current.IsTakePhotoSupported)
                {
                    await showDialog("Alert!", "Your device seems inappropriate for media. Try this on different device.");
                    return;
                }

                if (!_tesseractApi.Initialized)
                    await _tesseractApi.Init("eng");

                var file = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions
                {
                    CompressionQuality = 35,
                    PhotoSize = PhotoSize.Custom,
                    CustomPhotoSize = 10
                });

                if (file == null)
                    return;

                //start loader and start reading
                var dialog = UserDialogs.Instance;
                dialog.ShowLoading("Working, Please wait...", MaskType.Black);

                var memoryStream = new MemoryStream();
                await file.GetStream().CopyToAsync(memoryStream);
                byte[] imageAsByte = memoryStream.ToArray();

                var tessResult = await _tesseractApi.SetImage(imageAsByte);
                if (tessResult)
                {
                    var scannedText = _tesseractApi.Text;
                    System.Diagnostics.Debug.WriteLine("scanned : " + scannedText);
                    await ParsScannedText(scannedText);
                }

                file.Dispose();
                dialog.HideLoading();
            });

            IsBusy = false;
        }

        private async void NavigateBack()
        {
            if (IsBusy)
                return;

            IsBusy = true;
            await _navigationService.GoBackAsync();
            IsBusy = false;
        }

        private async Task ParsScannedText(string scannedText)
        {
            if (IsBusy)
                return;

            IsBusy = true;

            if (scannedText.Contains("name") ||
               scannedText.Contains("phone") ||
               scannedText.Contains("email") ||
               scannedText.Contains("website") ||
               scannedText.Contains("title")
              )
            {
                System.Diagnostics.Debug.WriteLine("something exists");
            }

            IsBusy = false;
        }

        public void OnNavigatedFrom(NavigationParameters parameters)
        {

        }

        public void OnNavigatedTo(NavigationParameters parameters)
        {

        }

        public void OnNavigatingTo(NavigationParameters parameters)
        {

        }

        private async Task showDialog(string title, string msg)
        {
            await _dialogService.DisplayAlertAsync(title, msg, "OK");
        }

        //buisness card
        private Color _buisnessBarColor = Color.FromHex("#3677A0");
        public Color buisnessBarColor
        {
            get { return _buisnessBarColor; }
            set { SetProperty(ref _buisnessBarColor, value); }
        }

        private Color _buisnessBarTextColor = Color.FromHex("#3677A0");
        public Color buisnessBarTextColor
        {
            get { return _buisnessBarTextColor; }
            set { SetProperty(ref _buisnessBarTextColor, value); }
        }

        private bool _layoutBuisness = true;
        public bool layoutBuisness
        {
            get { return _layoutBuisness; }
            set { SetProperty(ref _layoutBuisness, value); }
        }

        //web card
        private Color _webBarColor = Color.White;
        public Color webBarColor
        {
            get { return _webBarColor; }
            set { SetProperty(ref _webBarColor, value); }
        }

        private Color _webBarTextColor = Color.FromHex("#c3c3c3");
        public Color webBarTextColor
        {
            get { return _webBarTextColor; }
            set { SetProperty(ref _webBarTextColor, value); }
        }

        private bool _layoutWeb = false;
        public bool layoutWeb
        {
            get { return _layoutWeb; }
            set { SetProperty(ref _layoutWeb, value); }
        }

        //methods
        private void BuisnessCommandSelected()
        {
            SwitchSelectedTabTo(1);
        }
        private void WebCommandSelected()
        {
            SwitchSelectedTabTo(2);
        }

        private void SwitchSelectedTabTo(int v)
        {
            ResetAllTabs();
            switch (v)
            {
                case 1:
                    buisnessBarColor = Color.FromHex("#3677A0");
                    buisnessBarTextColor = Color.FromHex("#3677A0");
                    layoutBuisness = true;
                    break;
                case 2:
                    webBarColor = Color.FromHex("#3677A0");
                    webBarTextColor = Color.FromHex("#3677A0");
                    layoutWeb = true;
                    break;
            }
        }

        private void ResetAllTabs()
        {
            buisnessBarColor = Color.White;
            buisnessBarTextColor = Color.FromHex("#c3c3c3");
            layoutBuisness = false;

            webBarColor = Color.White;
            webBarTextColor = Color.FromHex("#c3c3c3");
            layoutWeb = false;
        }

    }
}

