﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Threading.Tasks;
using Acr.UserDialogs;
using Plugin.Media;
using Plugin.Media.Abstractions;
using Prism.Commands;
using Prism.Navigation;
using Prism.Services;
using QRCodePro.Helpers;
using QRCodePro.Models;
using QRCodePro.Services;
using QRCodePro.Views;
using Xamarin.Forms;

namespace QRCodePro.ViewModels
{
    public class ProfileViewPageViewModel : BaseViewModel, INavigationAware
    {
        private INavigationService _navigationService;
        private IPageDialogService _dialogService;
        public IDependencyService _dependencyService;
        public DataService dataService = new DataService();

        public DelegateCommand OnClickMenu { set; get; }
        public DelegateCommand OnClickEditProfile { get; set; }
        public DelegateCommand OnListRefreshing { get; set; }

		private bool _isRefreshingList = false;
		public bool isRefreshingList
		{
			get { return _isRefreshingList; }
			set { SetProperty(ref _isRefreshingList, value); }
		}

		private ObservableCollection<PicturePost> _PostsList = new ObservableCollection<PicturePost>();
		public ObservableCollection<PicturePost> PostsList
		{
			get { return _PostsList; }
			set { SetProperty(ref _PostsList, value); }
		}

        private string _name = Settings.UserName;
        public string Name
        {
            get { return _name; }
            set { SetProperty(ref _name, value); }
        }
        private string _email = Settings.UserEmail;
        public string Email
        {
            get { return _email; }
            set { SetProperty(ref _email, value); }
        }
        private string _phone = Settings.UserPhone;
        public string Phone
        {
            get { return _phone; }
            set { SetProperty(ref _phone, value); }
        }
        private string _profilepic = Settings.UserProfilePic;
        public string ProfilePic
        {
            get { return _profilepic; }
            set { SetProperty(ref _profilepic, value); }
        }
        private Xamarin.Forms.ImageSource _QrcodeImage;
        public Xamarin.Forms.ImageSource QrcodeImage
        {
            get { return _QrcodeImage; }
            set { SetProperty(ref _QrcodeImage, value); }
        }
        private string _buisnesname = "";
        public string BuisnesName
        {
            get { return _buisnesname; }
            set { SetProperty(ref _buisnesname, value); }
        }
        private string _buisnesdescription = "";
        public string BuisnesDescription
        {
            get { return _buisnesdescription; }
            set { SetProperty(ref _buisnesdescription, value); }
        }



        public ProfileViewPageViewModel(INavigationService navigationService,
                                      IPageDialogService dialogService,
                                     IDependencyService dependencyService)
        {
            _navigationService = navigationService;
            _dialogService = dialogService;
            _dependencyService = dependencyService;

            OnClickMenu = new DelegateCommand(openMenuWindow);
            OnClickEditProfile = new DelegateCommand(NavigateToEditProfile);
            OnListRefreshing = new DelegateCommand(RefreshPostsList);
        }

        private async void SetUpInfo()
        {
            if (IsBusy) return;
            IsBusy = true;
            var dialog = UserDialogs.Instance;
            dialog.ShowLoading("Please wait...", MaskType.Black);
            AccountResponse response = await dataService.GetProfileInfo();
            if (response != null)
            {
                if (response.status.Equals("failure"))
                {
                    await showDialog("Alert!", "Oops, " + response.message);
                }
                else if (response.status.Equals("success"))
                {
                    if (response.data != null)
                    {
                        Settings.UserId = response.data.id;
                        Settings.UserName = response.data.name;
                        Settings.UserEmail = response.data.email;
                        Settings.UserPhone = response.data.phone;
                        Settings.UserType = response.data.user_type;
                        Settings.UserProfilePic = response.data.profile_pic;
                        Settings.UserQRCodePic = response.data.qrcode_pic;
                        Settings.CompanyName = response.data.c_name;
                        Settings.CompanyAddress = response.data.c_address;
                        Settings.CompanyWebsite = response.data.c_website;

                        dialog.HideLoading();
                        string data = "{ \"format\":\"card\" , \"data\":{\"p_name\":\"" + Settings.UserName
                                    + "\",\"c_name\":\"" + response.data.c_name
                                    + "\",\"phone\":\"" + response.data.phone
                                    + "\",\"fax\":\"" + response.data.phone
                                    + "\",\"address\":\"" + response.data.c_address
                                    + "\",\"website\":\"" + response.data.c_website
                                    + "\"} }";

                        LoadQrcodeImage(data);
                        BuisnesName = Settings.CompanyName;
                        BuisnesDescription = Settings.CompanyName + " has no description available.";
                    }
                }
                dialog.HideLoading();
            }
            else
            {
                dialog.HideLoading();
                await showDialog("Alert!", "You are not connected to internet, please try again later.");
            }
            IsBusy = false;
        }

        private void openMenuWindow()
        {
            RootPage.Instance.IsPresented = true;
        }

        private async void NavigateToEditProfile()
        {
            if (IsBusy) return;
            IsBusy = true;
            await _navigationService.NavigateAsync("ProfileEditPage",null,true,true);
            IsBusy = false;
        }



		public async Task TakeImageFromGallery()
		{
			if (IsBusy) return;
			IsBusy = true;

			Device.BeginInvokeOnMainThread(async () =>
			{
				if (!await CrossMedia.Current.Initialize())
				{
					await showDialog("Alert!", "Your device seems inappropriate for media. Try this on different device.");
					return;
				}

				if (!CrossMedia.Current.IsPickPhotoSupported)
				{
					await showDialog("Alert!", "Your device seems inappropriate for media. Try this on different device.");
					return;
				}

				var file = await CrossMedia.Current.PickPhotoAsync(new PickMediaOptions
				{
					CompressionQuality = 20,
					PhotoSize = PhotoSize.Small
				});

				if (file == null)
					return;

				var memoryStream = new MemoryStream();
				await file.GetStream().CopyToAsync(memoryStream);
				byte[] imageAsByte = memoryStream.ToArray();

				ProfilePic = System.Convert.ToBase64String(imageAsByte);
                await SendProfilePicToServer();
                file.Dispose();
			});
			IsBusy = false;
		}

		public async Task TakeImageFromCamera()
		{
			if (IsBusy) return;
			IsBusy = true;

			Device.BeginInvokeOnMainThread(async () =>
			{
				if (!await CrossMedia.Current.Initialize())
				{
					await showDialog("Alert!", "Your device seems inappropriate for media. Try this on different device.");
					return;
				}

				if (!CrossMedia.Current.IsPickPhotoSupported)
				{
					await showDialog("Alert!", "Your device seems inappropriate for media. Try this on different device.");
					return;
				}

				var file = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions
				{
					CompressionQuality = 20,
					PhotoSize = PhotoSize.Custom,
					CustomPhotoSize = 10
				});

				if (file == null)
					return;

				var memoryStream = new MemoryStream();
				await file.GetStream().CopyToAsync(memoryStream);
				byte[] imageAsByte = memoryStream.ToArray();

                ProfilePic = System.Convert.ToBase64String(imageAsByte);
                await SendProfilePicToServer();
                file.Dispose();
			});
			IsBusy = false;
		}

        private async Task SendProfilePicToServer()
        {
			var dialog = UserDialogs.Instance;
			dialog.ShowLoading("Please wait...", MaskType.Black);
            StatusResponse response = await dataService.UpdateProfilePicture(ProfilePic);
			if (response != null)
			{
                dialog.HideLoading();
                if (response.status.Equals("failure"))
                {
                    await showDialog("Alert!", "Oops, " + response.message);
                }
                else if (response.status.Equals("success"))
                {
                    Settings.UserProfilePic = response.message;
                    ProfilePic = response.message;
                }
			}
			else
			{
				dialog.HideLoading();
				await showDialog("Alert!", "You are not connected to internet, please try again later.");
			}
        }

		private async void RefreshPostsList()
		{
			if (IsBusy) return;
			IsBusy = true;
			isRefreshingList = true;

			PicturePostResponse response = await dataService.getAllPicturePostsOfUser();
			if (response != null)
			{
				if (response.status.Equals("success"))
				{
					PostsList.Clear();
					List<PicturePost> items = new List<PicturePost>();
					foreach (PicturePost row in response.data)
					{
						DateTime dateValue;
						if (DateTime.TryParse(row.createdAt.date, out dateValue))
						{
							row.time = TimeAgo(dateValue);
						}
						else
						{
							row.time = "N/A";
						}
						System.Diagnostics.Debug.WriteLine("time : " + row.time);
						items.Add(row);
					}
					PostsList = new ObservableCollection<PicturePost>(items);

				}
			}
			else
			{
				isRefreshingList = false;
				await showDialog("Alert!", "You are not connected to internet, please try again later.");
			}
			IsBusy = false;
			isRefreshingList = false;
		}

		public async Task PageChangeAsync(PicturePost item)
		{
			var navigationParams = new NavigationParameters();
			navigationParams.Add("model", item);
			await _navigationService.NavigateAsync("ViewPostDetailPage", navigationParams, true, true);
		}

        public void OnNavigatedFrom(NavigationParameters parameters)
        {
        }

        public void OnNavigatedTo(NavigationParameters parameters)
        {
            SetUpInfo();
            RefreshPostsList();
        }

        public void OnNavigatingTo(NavigationParameters parameters)
        {
        }

        public async Task showDialog(string title, string msg)
        {
            await _dialogService.DisplayAlertAsync(title, msg, "OK");
        }

        private async void LoadQrcodeImage(string data)
        {
            var dialog = UserDialogs.Instance;
            dialog.ShowLoading("Please wait...", MaskType.Black);

            var pic = await GenerateBarCode(data.Trim(), ZXing.BarcodeFormat.QR_CODE);
            QrcodeImage = await LoadImageAsync(pic);

            dialog.HideLoading();
        }

        private async Task<Xamarin.Forms.ImageSource> LoadImageAsync(string ImageBase64)
        {
            Task<Xamarin.Forms.ImageSource> result = Task<Xamarin.Forms.ImageSource>.Factory.StartNew(() => Xamarin.Forms.ImageSource.FromStream(
                () => new MemoryStream(Convert.FromBase64String(ImageBase64))));
            return await result;
        }

        private async Task<string> GenerateBarCode(string barcodeText, ZXing.BarcodeFormat format)
        {
            if (_dependencyService.Get<IBarcodeService>() != null)
            {
                var stream = _dependencyService.Get<IBarcodeService>().ConvertImageStream(barcodeText, format);
                return await EncodeImageToBase64(stream);
            }
            else
                return "";
        }

        private async Task<string> EncodeImageToBase64(Stream stream)
        {
            var bytes = new byte[stream.Length];
            await stream.ReadAsync(bytes, 0, (int)stream.Length);
            return System.Convert.ToBase64String(bytes);
        }

		//helper method
		public static string TimeAgo(DateTime dt)
		{
			TimeSpan span = DateTime.Now - dt;
			if (span.Days > 365)
			{
				int years = (span.Days / 365);
				if (span.Days % 365 != 0)
					years += 1;
				return String.Format("{0} {1} ago",
				years, years == 1 ? "year" : "years");
			}
			if (span.Days > 30)
			{
				int months = (span.Days / 30);
				if (span.Days % 31 != 0)
					months += 1;
				return String.Format("{0} {1} ago",
				months, months == 1 ? "month" : "months");
			}
			if (span.Days > 0)
				return String.Format("{0} {1} ago",
				span.Days, span.Days == 1 ? "day" : "days");
			if (span.Hours > 0)
				return String.Format("{0} {1} ago",
				span.Hours, span.Hours == 1 ? "hour" : "hours");
			if (span.Minutes > 0)
				return String.Format("{0} {1} ago",
				span.Minutes, span.Minutes == 1 ? "minute" : "minutes");
			if (span.Seconds > 5)
				return String.Format("{0} seconds ago", span.Seconds);
			if (span.Seconds <= 5)
				return "just now";
			return string.Empty;
		}
    }
}
