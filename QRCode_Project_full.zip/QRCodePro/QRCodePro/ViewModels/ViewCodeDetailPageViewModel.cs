﻿using Prism.Commands;
using Prism.Navigation;
using Prism.Services;
using QRCodePro.Helpers;
using QRCodePro.Services;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;
using System;
using Acr.UserDialogs;
using QRCodePro.Models;
using Newtonsoft.Json.Linq;

namespace QRCodePro.ViewModels
{
    public class ViewCodeDetailPageViewModel : BaseViewModel, INavigationAware
    {
        private INavigationService _navigationService;
        private IPageDialogService _dialogService;
        public IDependencyService _dependencyService;
        private DataService dataService = new DataService();

        public bool IsFromProfile { get; set; }
        public string CodeStringData { get; set; }
        public JObject CodeJsonData { get; set; }

        public DelegateCommand OnClickBack { get; set; }
        public DelegateCommand OnClickDelete { get; set; }
        public DelegateCommand OnClickSaveInDevice { get; set; }
        public DelegateCommand OnClickSaveInProfile { get; set; }
        public DelegateCommand OnClickSaveInProfileAndDevice { get; set; }

        private bool _isLoggedIn = Settings.IsLoggedIn;
        public bool IsLoggedIn
        {
            get { return _isLoggedIn; }
            set { SetProperty(ref _isLoggedIn, value); }
        }

        private Xamarin.Forms.ImageSource _QrcodeImage;
        public Xamarin.Forms.ImageSource QrcodeImage
        {
            get { return _QrcodeImage; }
            set { SetProperty(ref _QrcodeImage, value); }
        }

        private byte[] _QrcodeImageBytes;
        public byte[] QrcodeImageBytes
        {
            get { return _QrcodeImageBytes; }
            set { SetProperty(ref _QrcodeImageBytes, value); }
        }

        private BuisnessCard _bcardDetail;
        public BuisnessCard BuisnessCardDetail
        {
            get { return _bcardDetail; }
            set { SetProperty(ref _bcardDetail, value); }
        }

        private bool _canDelete = false;
        public bool CanDelete
        {
            get { return _canDelete; }
            set { SetProperty(ref _canDelete, value); }
        }

        public ViewCodeDetailPageViewModel(INavigationService navigationService,
                                      IPageDialogService dialogService,
                                     IDependencyService dependencyService)
        {
            _navigationService = navigationService;
            _dialogService = dialogService;
            _dependencyService = dependencyService;

            IsFromProfile = false;

            OnClickBack = new DelegateCommand(NavigateBack);
            OnClickDelete = new DelegateCommand(ClickedDelete);
            OnClickSaveInDevice = new DelegateCommand(ClickedSaveInDevice);
            OnClickSaveInProfile = new DelegateCommand(ClickedSaveInProfile);
            OnClickSaveInProfileAndDevice = new DelegateCommand(ClickedSaveInProfileNDevice);
        }

        private async void NavigateBack()
        {
            IsBusy = true;
            await _navigationService.GoBackAsync();
            IsBusy = false;
        }

        public async void ClickedDelete()
        {
            if (IsBusy && !CanDelete) return;
            IsBusy = true;
            var result = await UserDialogs.Instance.ConfirmAsync("Are you sure you want to Delete this Buisness Card?", "Alert!", "Yes", "No");
            if (result)
            {
                var dialog = UserDialogs.Instance;
                dialog.ShowLoading("Deleting, Please wait...", MaskType.Black);
                SavedCardsResponse response = await dataService.DeleteSavedCard(BuisnessCardDetail.id);
                if (response != null)
                {
                    if (response.status.Equals("failure"))
                    {
                        await showDialog("Alert!", "Oops, " + response.message);
                    }
                    else if (response.status.Equals("success"))
                    {
                        dialog.HideLoading();
                        UserDialogs.Instance.Toast("Buisness card has been deleted successfully.");
                        await _navigationService.GoBackAsync();
                    }
                    dialog.HideLoading();
                }
                else
                {
                    dialog.HideLoading();
                    await showDialog("Alert!", "You are not connected to internet, please try again later.");
                }
            }
            IsBusy = false;
        }

        private void ClickedSaveInDevice()
        {
            if (IsBusy) return;
            IsBusy = true;
            string type = (string)CodeJsonData["format"].ToString();

            if (type.Equals("card"))
            {
                JObject dataObj = (JObject)CodeJsonData["data"];
                string name = (string)dataObj["p_name"].ToString();
                _dependencyService.Get<IPicture>().SavePictureToDisk(name, QrcodeImageBytes);
                UserDialogs.Instance.Toast("QRCode is saved in your device storage.");
            }
            else
            {
                _dependencyService.Get<IPicture>().SavePictureToDisk(type, QrcodeImageBytes);
                UserDialogs.Instance.Toast("QRCode is saved in your device storage.");
            }
            IsBusy = false;
        }

        private async void ClickedSaveInProfile()
        {
            IsBusy = true;

            if (!IsFromProfile)
            {
                var dialog = UserDialogs.Instance;
                dialog.ShowLoading("Please wait...", MaskType.Black);
                SavedCardsResponse response = await dataService.AddNewBuisnesCard(CodeStringData);
                if (response != null)
                {
                    if (response.status.Equals("failure"))
                    {
                        dialog.HideLoading();
                        await showDialog("Alert!", "Oops, " + response.message);
                    }
                    else if (response.status.Equals("success"))
                    {
                        dialog.HideLoading();
                        UserDialogs.Instance.Toast("QRCode is saved in your profile.");
                    }
                    dialog.HideLoading();
                }
                else
                {
                    dialog.HideLoading();
                    await showDialog("Alert!", "You are not connected to internet, please try again later.");
                }
            }
            else
            {
                await showDialog("Alert!", "This QRCode is already saved in your profile.");
            }

            IsBusy = false;
        }

        private async void ClickedSaveInProfileNDevice()
        {
            IsBusy = true;
            if (!IsFromProfile)
            {
                var dialog = UserDialogs.Instance;
                dialog.ShowLoading("Please wait...", MaskType.Black);
                SavedCardsResponse response = await dataService.AddNewBuisnesCard(CodeStringData);
                if (response != null)
                {
                    if (response.status.Equals("failure"))
                    {
                        dialog.HideLoading();
                        await showDialog("Alert!", "Oops, " + response.message);
                    }
                    else if (response.status.Equals("success"))
                    {
                        string type = (string)CodeJsonData["format"].ToString();

                        if (type.Equals("card"))
                        {
                            JObject dataObj = (JObject)CodeJsonData["data"];
                            string name = (string)dataObj["p_name"].ToString();
                            _dependencyService.Get<IPicture>().SavePictureToDisk(name, QrcodeImageBytes);
                        }
                        else
                        {
                            _dependencyService.Get<IPicture>().SavePictureToDisk(type, QrcodeImageBytes);
                        }
                        dialog.HideLoading();
                        UserDialogs.Instance.Toast("QRCode is saved in your profile and to your device.");
                        await _navigationService.GoBackAsync();
                    }
                    dialog.HideLoading();
                }
                else
                {
                    dialog.HideLoading();
                    await showDialog("Alert!", "You are not connected to internet, please try again later.");
                }
            }
            else
            {
                string type = (string)CodeJsonData["format"].ToString();

                if (type.Equals("card"))
                {
                    JObject dataObj = (JObject)CodeJsonData["data"];
                    string name = (string)dataObj["p_name"].ToString();
                    _dependencyService.Get<IPicture>().SavePictureToDisk(name, QrcodeImageBytes);
                }
                else
                {
                    _dependencyService.Get<IPicture>().SavePictureToDisk(type, QrcodeImageBytes);
                }
                UserDialogs.Instance.Toast("QRCode is saved in your profile and to your device.");
            }
            IsBusy = false;
        }

        public void OnNavigatedFrom(NavigationParameters parameters)
        {

        }

        public void OnNavigatedTo(NavigationParameters parameters)
        {
            if (parameters.ContainsKey("model"))
            {
                BuisnessCardDetail = (BuisnessCard)parameters["model"];
                CodeStringData = BuisnessCardDetail.data;
                CodeJsonData = (JObject)JsonConvert.DeserializeObject(CodeStringData);
                LoadQrcodeImage();

                if (BuisnessCardDetail.users != null)
                {
                    if (BuisnessCardDetail.users.id.Equals(Settings.UserId))
                        CanDelete = true;
                    else
                        CanDelete = false;
                }
                else
                {
                    CanDelete = false;
                }
            }

            if (parameters.ContainsKey("FromProfile"))
                IsFromProfile = true;
            else
                IsFromProfile = false;
        }

        //     private async Task<FormattedQRCode> DecompileQRCodeData(string data)
        //     {
        //         JsonSerializer _serializer = new JsonSerializer();
        //using (var stream = await data.ReadAsStreamAsync())
        //using (var reader = new StreamReader(stream))
        //using (var json = new JsonTextReader(reader))
        //{
        //	return _serializer.Deserialize<FormattedQRCode>(json);
        //}
        //}

        public void OnNavigatingTo(NavigationParameters parameters)
        {

        }

        private async Task showDialog(string title, string msg)
        {
            await _dialogService.DisplayAlertAsync(title, msg, "OK");
        }

        private async void LoadQrcodeImage()
        {
            var dialog = UserDialogs.Instance;
            dialog.ShowLoading("Please wait...", MaskType.Black);

            var pic = await GenerateBarCode(CodeStringData.Trim(), ZXing.BarcodeFormat.QR_CODE);
            QrcodeImage = await LoadImageAsync(pic);

            dialog.HideLoading();
        }

        private async Task<Xamarin.Forms.ImageSource> LoadImageAsync(string ImageBase64)
        {
            Task<Xamarin.Forms.ImageSource> result = Task<Xamarin.Forms.ImageSource>.Factory.StartNew(() => Xamarin.Forms.ImageSource.FromStream(
                () => new MemoryStream(Convert.FromBase64String(ImageBase64))));
            return await result;
        }

        private async Task<string> GenerateBarCode(string barcodeText, ZXing.BarcodeFormat format)
        {
            if (_dependencyService.Get<IBarcodeService>() != null)
            {
                var stream = _dependencyService.Get<IBarcodeService>().ConvertImageStream(barcodeText, format);
                return await EncodeImageToBase64(stream);
            }
            else
                return "";
        }

        private async Task<string> EncodeImageToBase64(Stream stream)
        {
            var bytes = new byte[stream.Length];
            await stream.ReadAsync(bytes, 0, (int)stream.Length);
            QrcodeImageBytes = bytes;
            return System.Convert.ToBase64String(bytes);
        }
    }
}

