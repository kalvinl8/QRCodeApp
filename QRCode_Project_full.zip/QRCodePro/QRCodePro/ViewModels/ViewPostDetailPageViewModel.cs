﻿using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.Linq;
using Prism.Services;
using Acr.UserDialogs;
using QRCodePro.Helpers;
using Newtonsoft.Json.Linq;
using QRCodePro.Services;
using System.Diagnostics;
using QRCodePro.Models;
using System.Threading.Tasks;

namespace QRCodePro.ViewModels
{
    public class ViewPostDetailPageViewModel : BaseViewModel, INavigationAware
    {
        private INavigationService _navigationService;
        private IPageDialogService _dialogService;
        private DataService dataService = new DataService();

        public DelegateCommand OnClickBack { get; set; }
        public DelegateCommand OnClickDelete { get; set; }

        private PicturePost _postDetail = new PicturePost();
        public PicturePost PostDetail
        {
            get { return _postDetail; }
            set { SetProperty(ref _postDetail, value); }
        }

        private bool _canDelete = false;
        public bool CanDelete
        {
            get { return _canDelete; }
            set { SetProperty(ref _canDelete, value); }
        }

        public ViewPostDetailPageViewModel(INavigationService navigationService, IPageDialogService dialogService)
        {
            _navigationService = navigationService;
            _dialogService = dialogService;

            OnClickBack = new DelegateCommand(NavigateBack);
            OnClickDelete = new DelegateCommand(ClickedDelete);
        }

        private async void NavigateBack()
        {
            if (IsBusy) return;
            IsBusy = true;
            await _navigationService.GoBackAsync();
            IsBusy = false;
        }

        public async void ClickedViewProfile()
        {
            if (IsBusy || PostDetail.users.id.Equals(Settings.UserId)) return;
            IsBusy = true;
            var navigationParams = new NavigationParameters();
            navigationParams.Add("model", PostDetail.users);
            await _navigationService.NavigateAsync("ViewUserDetailPage", navigationParams, true, true);
            IsBusy = false;
        }

        public async void ClickedDelete()
        {
            if (IsBusy && !CanDelete) return;
            IsBusy = true;
            var result = await UserDialogs.Instance.ConfirmAsync("Are you sure you want to Delete this post?", "Alert!", "Yes", "No");
            if (result)
            {
                var dialog = UserDialogs.Instance;
                dialog.ShowLoading("Deleting, Please wait...", MaskType.Black);
                PicturePostResponse response = await dataService.DeletePicturePost(PostDetail.id);
                if (response != null)
                {
                    if (response.status.Equals("failure"))
                    {
                        await showDialog("Alert!", "Oops, " + response.message);
                    }
                    else if (response.status.Equals("success"))
                    {
                        dialog.HideLoading();
                        UserDialogs.Instance.Toast("Post has been deleted successfully.");
                        await _navigationService.GoBackAsync();
                    }
                    dialog.HideLoading();
                }
                else
                {
                    dialog.HideLoading();
                    await showDialog("Alert!", "You are not connected to internet, please try again later.");
                }
            }
            IsBusy = false;
        }

        public void OnNavigatedFrom(NavigationParameters parameters)
        {

        }

        public void OnNavigatedTo(NavigationParameters parameters)
        {
            if (parameters.ContainsKey("model"))
            {
                PostDetail = (PicturePost)parameters["model"];

                if (PostDetail.users.id.Equals(Settings.UserId))
                {
                    CanDelete = true;
                }
                else
                {
                    CanDelete = false;
                }
            }
        }

        public void OnNavigatingTo(NavigationParameters parameters)
        {

        }

        private async Task showDialog(string title, string msg)
        {
            await _dialogService.DisplayAlertAsync(title, msg, "OK");
        }
    }
}

