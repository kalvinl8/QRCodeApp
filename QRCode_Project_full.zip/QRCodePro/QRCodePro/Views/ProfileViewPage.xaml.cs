﻿using System;
using System.Collections.Generic;
using Acr.UserDialogs;
using QRCodePro.Models;
using QRCodePro.ViewModels;
using Xamarin.Forms;

namespace QRCodePro.Views
{
    public partial class ProfileViewPage : ContentPage
    {
        private ProfileViewPageViewModel ViewModel => this.BindingContext as ProfileViewPageViewModel;

        public ProfileViewPage()
        {
            NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
        }

        async void OnClickProfilePic(object sender, System.EventArgs e)
        {
			string[] modes = { "Select From Gallery", "Take New Picture" };

			string selectedMode = await DisplayActionSheet(
						"Choose Mode", "Cancel", null, modes
					);

			switch (selectedMode)
			{
				case "Select From Gallery":
					await ViewModel.TakeImageFromGallery();
					break;
				case "Take New Picture":
					await ViewModel.TakeImageFromCamera();
					break;
				default:
					break;
			}
        }

		private async void onListItemSelected(object sender, SelectedItemChangedEventArgs e)
		{
			if (e.SelectedItem == null)
				return;
			var post = e.SelectedItem as PicturePost;
			await ViewModel.PageChangeAsync(post);
			((ListView)sender).SelectedItem = null;
		}
    }
}
