﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace QRCodePro.Views
{
    public partial class DashboardPage : ContentPage
    {
        public DashboardPage()
        {
            NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
        }
    }
}
