﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace QRCodePro.Views
{
    public partial class LoginPage : ContentPage
    {
        public LoginPage()
        {
            NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
        }
    }
}
