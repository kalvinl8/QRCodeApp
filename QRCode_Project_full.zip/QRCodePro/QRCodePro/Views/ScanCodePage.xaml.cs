﻿using Newtonsoft.Json;
using Plugin.Media;
using QRCodePro.ViewModels;
using Xamarin.Forms;

namespace QRCodePro.Views
{
    public partial class ScanCodePage : ContentPage
    {
        private ScanCodePageViewModel ViewModel => this.BindingContext as ScanCodePageViewModel;

        public ScanCodePage()
        {
            NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            ScanQrcode();
        }

        private async void ScanQrcode()
        {
            await CrossMedia.Current.Initialize();
            if (!CrossMedia.Current.IsCameraAvailable)
            {
                await ViewModel.showDialog("Alert!", "No Camera is available. This feature requires a camera to work properly.");
                return;
            }
            var scanner = new ZXing.Mobile.MobileBarcodeScanner();
            var result = await scanner.Scan();
            if (result != null)
            {
                if (result.Text.Trim().Contains("{ \"format\":"))
                {
                    dynamic CodeJsonData = JsonConvert.DeserializeObject(result.Text.Trim());
                    ViewModel.DecodeQRCode(CodeJsonData);
                }
                else
                {
                    await ViewModel.showDialog("Alert!", "This type of QRCode is not supported, it is not a valid Buisness card or url QRCode.");
                }
            }
        }
    }
}
