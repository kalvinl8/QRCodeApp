﻿using System;
using System.Collections.Generic;
using QRCodePro.ViewModels;
using Xamarin.Forms;

namespace QRCodePro.Views
{
    public partial class RegisterPage : ContentPage
    {
        private RegisterPageViewModel ViewModel => this.BindingContext as RegisterPageViewModel;

        public RegisterPage()
        {
            NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
        }

        void Handle_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            ViewModel.ToggleViewPannel();
        }
    }
}
