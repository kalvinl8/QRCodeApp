﻿using System;
using System.Collections.Generic;
using QRCodePro.Models;
using QRCodePro.ViewModels;
using Xamarin.Forms;

namespace QRCodePro.Views
{
    public partial class ViewPostsPage : ContentPage
    {
        private ViewPostsPageViewModel ViewModel => this.BindingContext as ViewPostsPageViewModel;

        public ViewPostsPage()
        {
            NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
        }

		private async void onListItemSelected(object sender, SelectedItemChangedEventArgs e)
		{
			if (e.SelectedItem == null)
				return;
			var post = e.SelectedItem as PicturePost;
            await ViewModel.PageChangeAsync(post);
			((ListView)sender).SelectedItem = null;
		}

		private void onListItemTaped(object sender, ItemTappedEventArgs e)
		{
			//if (e.Item == null)
			//  return;

			//await ViewModel.PageChangeAsync(e.Item as Pickup);
			//((ListView)sender).SelectedItem = null;
		}
    }
}
