﻿using QRCodePro.ViewModels;
using Xamarin.Forms;

namespace QRCodePro.Views
{
    public partial class ProfileEditPage : ContentPage
    {
        private ProfileEditPageViewModel ViewModel => this.BindingContext as ProfileEditPageViewModel;

        public ProfileEditPage()
        {
            NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
        }

		void Handle_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ViewModel.ToggleViewPannel();
		}
    }
}
