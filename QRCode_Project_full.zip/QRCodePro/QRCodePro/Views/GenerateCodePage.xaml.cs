﻿using System;
using System.Collections.Generic;
using QRCodePro.ViewModels;
using Xamarin.Forms;

namespace QRCodePro.Views
{
    public partial class GenerateCodePage : ContentPage
    {
        private GenerateCodePageViewModel ViewModel => this.BindingContext as GenerateCodePageViewModel;

        public GenerateCodePage()
        {
            NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
        }

        async void ClickedScanBuisnessCard(object sender, System.EventArgs e)
        {
            string[] modes = { "Select From Gallery", "Take New Picture" };

            string selectedMode = await DisplayActionSheet(
                        "Choose Mode", "Cancel", null, modes
                    );

            switch (selectedMode)
            {
                case "Select From Gallery":
                    await ViewModel.ScanBuisnessCardFromGallery();
                    break;
                case "Take New Picture":
                    await ViewModel.ScanBuisnessCardFromCamera();
                    break;
                default:
                    break;
            }
        }
    }
}
