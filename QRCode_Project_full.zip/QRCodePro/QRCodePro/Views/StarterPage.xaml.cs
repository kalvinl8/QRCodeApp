﻿using Xamarin.Forms;

namespace QRCodePro.Views
{
	public partial class StarterPage : ContentPage
	{
		public StarterPage ()
		{
            NavigationPage.SetHasNavigationBar(this, false);
			InitializeComponent ();
		}
	}
}

