﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace QRCodePro.Views
{
    public partial class ViewUserDetailPage : ContentPage
    {
        public ViewUserDetailPage()
        {
            NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
        }
    }
}
