﻿using System;
using System.Collections.Generic;
using QRCodePro.Models;
using QRCodePro.ViewModels;
using Xamarin.Forms;

namespace QRCodePro.Views
{
	public partial class MenuPage : ContentPage
	{
		private RootPageViewModel ViewModel => this.BindingContext as RootPageViewModel;

		public MenuPage()
		{
			InitializeComponent();
			NavigationPage.SetHasNavigationBar(this, false);
			//BackgroundColor = Color.FromHex("001a2b");
		}

		private async void onListItemSelected(object sender, SelectedItemChangedEventArgs e)
		{
			await ViewModel.PageChangeAsync(e.SelectedItem as MenuCellModel);
		}
	}
}
