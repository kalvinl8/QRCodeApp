﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using FFImageLoading.Forms;
using QRCodePro.Services;
using QRCodePro.ViewModels;
using Xamarin.Forms;

namespace QRCodePro.Views
{
    public partial class ViewCodeDetailPage : ContentPage
    {
        private ViewCodeDetailPageViewModel ViewModel => this.BindingContext as ViewCodeDetailPageViewModel;

        public ViewCodeDetailPage()
        {
            NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
        }
    }
}
