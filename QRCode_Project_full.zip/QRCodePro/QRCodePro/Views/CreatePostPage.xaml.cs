﻿using System;
using System.Collections.Generic;
using QRCodePro.ViewModels;
using Xamarin.Forms;

namespace QRCodePro.Views
{
    public partial class CreatePostPage : ContentPage
    {
        private CreatePostPageViewModel ViewModel => this.BindingContext as CreatePostPageViewModel;

        public CreatePostPage()
        {
            NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
        }

        void EditorTextChanged(object sender, TextChangedEventArgs e)
        {
            inputDescriptionTextCounter.Text = "(" + inputDescription.Text.Length + "/500)";
        }

        async void OnClickTapImage(object sender, System.EventArgs e)
        {
            string[] modes = { "Select From Gallery", "Take New Picture" };

            string selectedMode = await DisplayActionSheet(
                        "Choose Mode", "Cancel", null, modes
                    );

            switch (selectedMode)
            {
                case "Select From Gallery":
                    await ViewModel.TakeImageFromGallery();
                    break;
                case "Take New Picture":
                    await ViewModel.TakeImageFromCamera();
                    break;
                default:
                    break;
            }
        }
    }
}
