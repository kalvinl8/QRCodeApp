﻿using System;
using System.Collections.Generic;
using QRCodePro.ViewModels;
using Xamarin.Forms;

namespace QRCodePro.Views
{
    public partial class ViewPostDetailPage : ContentPage
    {
        private ViewPostDetailPageViewModel ViewModel => this.BindingContext as ViewPostDetailPageViewModel;

        public ViewPostDetailPage()
        {
            NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
        }

        void OnClickViewProfile(object sender, System.EventArgs e)
        {
            if (!ViewModel.IsBusy)
                ViewModel.ClickedViewProfile();
        }
    }
}
