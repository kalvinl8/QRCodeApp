﻿using System;
using System.Collections.Generic;
using QRCodePro.ViewModels;
using Xamarin.Forms;

namespace QRCodePro.Views
{
	public partial class RootPage : MasterDetailPage
	{
		private RootPageViewModel ViewModel => this.BindingContext as RootPageViewModel;
		static RootPage _instance;
		public static RootPage Instance
		{
			get { return _instance; }
		}

		public RootPage()
		{
			InitializeComponent();
			NavigationPage.SetHasNavigationBar(this, false);
			_instance = this;
		}

		protected override async void OnAppearing()
		{
			base.OnAppearing();
			//await ViewModel.PageChangeAsync(ViewModel.MenuList[0]);
		}
	}
}
