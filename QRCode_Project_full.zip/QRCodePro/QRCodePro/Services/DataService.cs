﻿using System.Net.Http;
using System.Collections.Generic;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;
using Plugin.Connectivity;
using QRCodePro.Helpers;
using ModernHttpClient;
using QRCodePro.Models;
using System.Diagnostics;
using System;

namespace QRCodePro.Services
{
    public class DataService
    {
        JsonSerializer _serializer = new JsonSerializer();
        public readonly HttpClient client = new HttpClient(new NativeMessageHandler());

        //string baseurl = "http://192.168.76.5/qrcodescanpro/api/webservices/";
        string baseurl = "http://qrcodescannerpro.000webhostapp.com/api/webservices/";

        public DataService()
        {
            client.BaseAddress = new System.Uri(baseurl);
            client.MaxResponseContentBufferSize = 256000;
        }

        public async Task<AccountResponse> Login(string email, string password)
        {
            if (!CrossConnectivity.Current.IsConnected)
                return null;

            try
            {
                //var data
                var content = new FormUrlEncodedContent(new[] {
                    new KeyValuePair<string,string>("email",email),
                    new KeyValuePair<string,string>("password",password)
                });

                var response = await client.PostAsync(baseurl + "login", content);
                response.EnsureSuccessStatusCode();

                using (var stream = await response.Content.ReadAsStreamAsync())
                using (var reader = new StreamReader(stream))
                using (var json = new JsonTextReader(reader))
                {
                    return _serializer.Deserialize<AccountResponse>(json);
                }
            }
            catch (TaskCanceledException e)
            {
                Debug.WriteLine("Exception : " + e.Message);
                return null;
            }
            catch (Exception el)
            {
                Debug.WriteLine("Exception : " + el.Message);
                return null;
            }
        }

        public async Task<AccountResponse> Register(string name, string email, string password, string phone,
                                           string type, string c_name, string c_add, string c_web)
        {
            if (!CrossConnectivity.Current.IsConnected)
                return null;

            try
            {
                //var data
                var content = new FormUrlEncodedContent(new[] {
                    new KeyValuePair<string,string>("name",name),
                    new KeyValuePair<string,string>("email",email),
                    new KeyValuePair<string,string>("password",password),
                    new KeyValuePair<string,string>("phone",phone),
                    new KeyValuePair<string,string>("user_type",type),
                    new KeyValuePair<string,string>("company_name",c_name),
                    new KeyValuePair<string,string>("company_address",c_add),
                    new KeyValuePair<string,string>("company_website",c_web)
                });

                var response = await client.PostAsync(baseurl + "register", content);
                response.EnsureSuccessStatusCode();

                using (var stream = await response.Content.ReadAsStreamAsync())
                using (var reader = new StreamReader(stream))
                using (var json = new JsonTextReader(reader))
                {
                    return _serializer.Deserialize<AccountResponse>(json);
                }
            }
            catch (TaskCanceledException e)
            {
                Debug.WriteLine("Exception : " + e.Message);
                return null;
            }
            catch (Exception el)
            {
                Debug.WriteLine("Exception : " + el.Message);
                return null;
            }
        }

		public async Task<AccountResponse> UpdateProfileInfo(string name, string email, string password, string phone,
										   string type, string c_name, string c_add, string c_web)
		{
			if (!CrossConnectivity.Current.IsConnected)
				return null;

			try
			{
				//var data
				var content = new FormUrlEncodedContent(new[] {
                    new KeyValuePair<string,string>("id",Settings.UserId),
					new KeyValuePair<string,string>("name",name),
					new KeyValuePair<string,string>("email",email),
					new KeyValuePair<string,string>("password",password),
					new KeyValuePair<string,string>("phone",phone),
					new KeyValuePair<string,string>("user_type",type),
					new KeyValuePair<string,string>("company_name",c_name),
					new KeyValuePair<string,string>("company_address",c_add),
					new KeyValuePair<string,string>("company_website",c_web)
				});

				var response = await client.PostAsync(baseurl + "update_profile_info", content);
				response.EnsureSuccessStatusCode();

				using (var stream = await response.Content.ReadAsStreamAsync())
				using (var reader = new StreamReader(stream))
				using (var json = new JsonTextReader(reader))
				{
					return _serializer.Deserialize<AccountResponse>(json);
				}
			}
			catch (TaskCanceledException e)
			{
				Debug.WriteLine("Exception : " + e.Message);
				return null;
			}
			catch (Exception el)
			{
				Debug.WriteLine("Exception : " + el.Message);
				return null;
			}
		}

		public async Task<AccountResponse> GetProfileInfo()
		{
			if (!CrossConnectivity.Current.IsConnected)
				return null;

			try
			{
				var response = await client.GetAsync(baseurl + "get_profile_info?id=" + Settings.UserId);
				response.EnsureSuccessStatusCode();
				using (var stream = await response.Content.ReadAsStreamAsync())
				using (var reader = new StreamReader(stream))
				using (var json = new JsonTextReader(reader))
				{
					return _serializer.Deserialize<AccountResponse>(json);
				}
			}
			catch (TaskCanceledException e)
			{
				Debug.WriteLine("Exception : " + e.Message);
				return null;
			}
			catch (Exception el)
			{
				Debug.WriteLine("Exception : " + el.Message);
				return null;
			}
		}

        public async Task<StatusResponse> UpdateProfilePicture(string picture)
		{
			if (!CrossConnectivity.Current.IsConnected)
				return null;

			try
			{
				//var data
				var content = new FormUrlEncodedContent(new[] {
                    new KeyValuePair<string,string>("id",Settings.UserId),
                    new KeyValuePair<string,string>("picture",picture)
				});

				var response = await client.PostAsync(baseurl + "update_profile_picture", content);
				response.EnsureSuccessStatusCode();

				using (var stream = await response.Content.ReadAsStreamAsync())
				using (var reader = new StreamReader(stream))
				using (var json = new JsonTextReader(reader))
				{
					return _serializer.Deserialize<StatusResponse>(json);
				}
			}
			catch (TaskCanceledException e)
			{
				Debug.WriteLine("Exception : " + e.Message);
				return null;
			}
			catch (Exception el)
			{
				Debug.WriteLine("Exception : " + el.Message);
				return null;
			}
		}

        public async Task<SavedCardsResponse> getAllSavedCards()
        {
            if (!CrossConnectivity.Current.IsConnected)
                return null;

            try
            {
                var response = await client.GetAsync(baseurl + "get_all_saved_cards?id=" + Settings.UserId);
                response.EnsureSuccessStatusCode();
                using (var stream = await response.Content.ReadAsStreamAsync())
                using (var reader = new StreamReader(stream))
                using (var json = new JsonTextReader(reader))
                {
                    return _serializer.Deserialize<SavedCardsResponse>(json);
                }
            }
            catch (TaskCanceledException e)
            {
                Debug.WriteLine("Exception : " + e.Message);
                return null;
            }
            catch (Exception el)
            {
                Debug.WriteLine("Exception : " + el.Message);
                return null;
            }
        }

        public async Task<SavedCardsResponse> AddNewBuisnesCard(string data)
		{
			if (!CrossConnectivity.Current.IsConnected)
				return null;

			try
			{
				//var data
				var content = new FormUrlEncodedContent(new[] {
					new KeyValuePair<string,string>("id",Settings.UserId),
                    new KeyValuePair<string,string>("data",data)
				});

				var response = await client.PostAsync(baseurl + "add_new_card", content);
				response.EnsureSuccessStatusCode();

				using (var stream = await response.Content.ReadAsStreamAsync())
				using (var reader = new StreamReader(stream))
				using (var json = new JsonTextReader(reader))
				{
					return _serializer.Deserialize<SavedCardsResponse>(json);
				}
			}
			catch (TaskCanceledException e)
			{
				Debug.WriteLine("Exception : " + e.Message);
				return null;
			}
			catch (Exception el)
			{
				Debug.WriteLine("Exception : " + el.Message);
				return null;
			}
		}

        public async Task<PicturePostResponse> CreateNewPicturePost(string description, string picture)
        {
            if (!CrossConnectivity.Current.IsConnected)
                return null;

            try
            {
                //var data
                var content = new FormUrlEncodedContent(new[] {
                    new KeyValuePair<string,string>("user_id",Settings.UserId),
                    new KeyValuePair<string,string>("picture",picture),
                    new KeyValuePair<string,string>("description",description)
                });

                var response = await client.PostAsync(baseurl + "add_new_picture_post", content);
                response.EnsureSuccessStatusCode();

                using (var stream = await response.Content.ReadAsStreamAsync())
                using (var reader = new StreamReader(stream))
                using (var json = new JsonTextReader(reader))
                {
                    return _serializer.Deserialize<PicturePostResponse>(json);
                }
            }
            catch (TaskCanceledException e)
            {
                Debug.WriteLine("Exception : " + e.Message);
                return null;
            }
            catch (Exception el)
            {
                Debug.WriteLine("Exception : " + el.Message);
                return null;
            }
        }

		public async Task<PicturePostResponse> getAllPicturePostsOfUser()
		{
			if (!CrossConnectivity.Current.IsConnected)
				return null;

			try
			{
				var response = await client.GetAsync(baseurl + "get_all_picture_posts_of_user?id=" + Settings.UserId);
				response.EnsureSuccessStatusCode();
				using (var stream = await response.Content.ReadAsStreamAsync())
				using (var reader = new StreamReader(stream))
				using (var json = new JsonTextReader(reader))
				{
					return _serializer.Deserialize<PicturePostResponse>(json);
				}
			}
			catch (TaskCanceledException e)
			{
				Debug.WriteLine("Exception : " + e.Message);
				return null;
			}
			catch (Exception el)
			{
				Debug.WriteLine("Exception : " + el.Message);
				return null;
			}
		}

		public async Task<PicturePostResponse> getAllPicturePosts()
		{
			if (!CrossConnectivity.Current.IsConnected)
				return null;

			try
			{
				var response = await client.GetAsync(baseurl + "get_all_picture_posts?id=" + Settings.UserId);
				response.EnsureSuccessStatusCode();
				using (var stream = await response.Content.ReadAsStreamAsync())
				using (var reader = new StreamReader(stream))
				using (var json = new JsonTextReader(reader))
				{
					return _serializer.Deserialize<PicturePostResponse>(json);
				}
			}
			catch (TaskCanceledException e)
			{
				Debug.WriteLine("Exception : " + e.Message);
				return null;
			}
			catch (Exception el)
			{
				Debug.WriteLine("Exception : " + el.Message);
				return null;
			}
		}

		public async Task<PicturePostResponse> DeletePicturePost(string post_id)
		{
			if (!CrossConnectivity.Current.IsConnected)
				return null;

			try
			{
				//var data
				var content = new FormUrlEncodedContent(new[] {
                    new KeyValuePair<string,string>("post_id",post_id)
				});

				var response = await client.PostAsync(baseurl + "delete_picture_post", content);
				response.EnsureSuccessStatusCode();

				using (var stream = await response.Content.ReadAsStreamAsync())
				using (var reader = new StreamReader(stream))
				using (var json = new JsonTextReader(reader))
				{
					return _serializer.Deserialize<PicturePostResponse>(json);
				}
			}
			catch (TaskCanceledException e)
			{
				Debug.WriteLine("Exception : " + e.Message);
				return null;
			}
			catch (Exception el)
			{
				Debug.WriteLine("Exception : " + el.Message);
				return null;
			}
		}

        public async Task<SavedCardsResponse> DeleteSavedCard(string post_id)
		{
			if (!CrossConnectivity.Current.IsConnected)
				return null;

			try
			{
				//var data
				var content = new FormUrlEncodedContent(new[] {
					new KeyValuePair<string,string>("card_id",post_id)
				});

				var response = await client.PostAsync(baseurl + "delete_saved_card", content);
				response.EnsureSuccessStatusCode();

				using (var stream = await response.Content.ReadAsStreamAsync())
				using (var reader = new StreamReader(stream))
				using (var json = new JsonTextReader(reader))
				{
					return _serializer.Deserialize<SavedCardsResponse>(json);
				}
			}
			catch (TaskCanceledException e)
			{
				Debug.WriteLine("Exception : " + e.Message);
				return null;
			}
			catch (Exception el)
			{
				Debug.WriteLine("Exception : " + el.Message);
				return null;
			}
		}

        public async Task<StatusResponse> CheckIsFollowing(string followerUserId)
		{
			if (!CrossConnectivity.Current.IsConnected)
				return null;

			try
			{
                var response = await client.GetAsync(baseurl + "is_following?id=" + Settings.UserId + "&following_id=" + followerUserId);
				response.EnsureSuccessStatusCode();
				using (var stream = await response.Content.ReadAsStreamAsync())
				using (var reader = new StreamReader(stream))
				using (var json = new JsonTextReader(reader))
				{
					return _serializer.Deserialize<StatusResponse>(json);
				}
			}
			catch (TaskCanceledException e)
			{
				Debug.WriteLine("Exception : " + e.Message);
				return null;
			}
			catch (Exception el)
			{
				Debug.WriteLine("Exception : " + el.Message);
				return null;
			}
		}

		public async Task<StatusResponse> FollowUnfollowStatusChange(string followerUserId)
		{
			if (!CrossConnectivity.Current.IsConnected)
				return null;

			try
			{
				var response = await client.GetAsync(baseurl + "change_follow_unfollow?id=" + Settings.UserId + "&following_id=" + followerUserId);
				response.EnsureSuccessStatusCode();
				using (var stream = await response.Content.ReadAsStreamAsync())
				using (var reader = new StreamReader(stream))
				using (var json = new JsonTextReader(reader))
				{
					return _serializer.Deserialize<StatusResponse>(json);
				}
			}
			catch (TaskCanceledException e)
			{
				Debug.WriteLine("Exception : " + e.Message);
				return null;
			}
			catch (Exception el)
			{
				Debug.WriteLine("Exception : " + el.Message);
				return null;
			}
		}
    }
}
