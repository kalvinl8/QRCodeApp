﻿using System;
namespace QRCodePro.Services
{
    public interface IPicture
    {
        void SavePictureToDisk(string filename, byte[] imageData);
    }
}
