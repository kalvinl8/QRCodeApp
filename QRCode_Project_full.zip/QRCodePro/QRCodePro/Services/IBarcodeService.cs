﻿using System;
using System.IO;

namespace QRCodePro.Services
{
	public interface IBarcodeService
	{
		Stream ConvertImageStream(string text, ZXing.BarcodeFormat format);
	}
}
