﻿using System;
namespace QRCodePro.Models
{
    public class PicturePostResponse
    {
        public string status { get; set; }
        public string message { get; set; }
        public PicturePost[] data { get; set; }
    }
}
