﻿using System;
namespace QRCodePro.Models
{
    public class UserProfile
    {
        public string id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string phone { get; set; }
        public string profile_pic { get; set; }
        public string qrcode_pic { get; set; }
        public string user_type { get; set; }
        public string c_name { get; set; }
        public string c_address { get; set; }
        public string c_website { get; set; }
        public DatabaseDateTime createdAt { get; set; }
    }
}
