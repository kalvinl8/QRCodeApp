﻿using System;
namespace QRCodePro.Models
{
    public class SavedCardsResponse
    {
		public string status { get; set; }
		public string message { get; set; }
        public BuisnessCard[] data { get; set; }
    }
}
