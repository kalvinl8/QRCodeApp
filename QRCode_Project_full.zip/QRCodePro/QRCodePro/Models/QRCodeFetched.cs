﻿using System;

namespace QRCodePro.Models
{
    public class QRCodeFetched
    {
		public string id { get; set; }
		public UserProfile users { get; set; }
		public string data { get; set; }
    }
}
