﻿using System;
namespace QRCodePro.Models
{
    public class AccountResponse
    {
        public string status { get; set; }
        public string message { get; set; }
        public UserProfile data { get; set; }
    }
}
