﻿using System;
using System.ComponentModel;

namespace QRCodePro.Models
{
    public class PicturePost
    {
        public string id { get; set; }
        public UserProfile users { get; set; }
        public string url { get; set; }
        public string description { get; set; }
        public string time { get; set; }
        public DatabaseDateTime createdAt { get; set; }
    }
}
