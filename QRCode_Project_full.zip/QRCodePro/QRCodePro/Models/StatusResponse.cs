﻿using System;
namespace QRCodePro.Models
{
    public class StatusResponse
    {
		public string status { get; set; }
		public string message { get; set; }
    }
}
