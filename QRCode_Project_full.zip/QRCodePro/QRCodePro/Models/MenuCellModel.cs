﻿using System;

namespace QRCodePro.Models
{
	public class MenuCellModel
	{
		public string MenuTitle { set; get; }
		public string logo { set; get; }
	}
}
