﻿using System;

namespace QRCodePro.Models
{
    public class BuisnessCard
    {
        public string id { get; set; }
        public UserProfile users { get; set; }
        public string data { get; set; }

        public string time { get; set; }
        public Xamarin.Forms.ImageSource qrcodeimage { get; set; }
        public DatabaseDateTime createdAt { get; set; }

        public string PersonName { get; set; }
        public string CompanyName { get; set; }
        public string PhoneNo { get; set; }
        public string FaxNo { get; set; }
        public string Website { get; set; }
        public string Address { get; set; }
    }
}
