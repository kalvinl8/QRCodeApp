﻿using System;
namespace QRCodePro.Models
{
    public class FormattedQRCode
    {
        public string format { get; set; }
        public QRCodeData data { get; set; }
    }

    public class QRCodeData
    {
        public string url { get; set; }

        public string p_name { get; set; }
        public string c_name { get; set; }
        public string phone { get; set; }
        public string fax { get; set; }
        public string address { get; set; }
        public string website { get; set; }
    }
}
