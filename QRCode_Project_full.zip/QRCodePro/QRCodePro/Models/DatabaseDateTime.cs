﻿using System;
namespace QRCodePro.Models
{
    public class DatabaseDateTime
    {
        public string date { get; set; }
        public string timezone_type { get; set; }
        public string timezone { get; set; }
    }
}
