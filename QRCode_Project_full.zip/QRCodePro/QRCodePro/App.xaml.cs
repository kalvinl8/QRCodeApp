﻿using Prism.Unity;
using QRCodePro.Views;
using QRCodePro.Helpers;
using Xamarin.Forms;
using Plugin.Permissions.Abstractions;
using Plugin.Permissions;
using System;
using System.Collections.Generic;
using QRCodePro.ViewModels;

namespace QRCodePro
{
    public partial class App : PrismApplication
    {
        public static App Instance { get; private set; }

        public App(IPlatformInitializer initializer = null) : base(initializer)
        {
            initializer?.RegisterTypes(Container);
            SetUpInitialiserPage();
            //Logout();
        }

        private async void SetUpInitialiserPage()
        {
            if (Settings.IsLoggedIn)
            {
                await NavigationService.NavigateAsync("RootPage/NavigationPage/DashboardPage");
            }
            else
            {
                await NavigationService.NavigateAsync("StarterPage");
            }
        }

        public async void Logout()
        {
            Settings.IsLoggedIn = false;
            await NavigationService.NavigateAsync("StarterPage");
        }

        protected override void OnInitialized()
        {
            InitializeComponent();
            Instance = this;
            CheckForPermissions();
        }

        protected override void RegisterTypes()
        {
            Container.RegisterTypeForNavigation<NavigationPage>();

            Container.RegisterTypeForNavigation<RootPage, RootPageViewModel>();
            Container.RegisterTypeForNavigation<DashboardPage, DashboardPageViewModel>();
            Container.RegisterTypeForNavigation<StarterPage, StarterPageViewModel>();
            Container.RegisterTypeForNavigation<LoginPage, LoginPageViewModel>();
            Container.RegisterTypeForNavigation<RegisterPage, RegisterPageViewModel>();
            Container.RegisterTypeForNavigation<CreatePostPage, CreatePostPageViewModel>();
            Container.RegisterTypeForNavigation<GenerateCodePage, GenerateCodePageViewModel>();
            Container.RegisterTypeForNavigation<ScanCodePage, ScanCodePageViewModel>();
            Container.RegisterTypeForNavigation<ProfileViewPage, ProfileViewPageViewModel>();
            Container.RegisterTypeForNavigation<ProfileEditPage, ProfileEditPageViewModel>();
            Container.RegisterTypeForNavigation<ViewPostsPage, ViewPostsPageViewModel>();
            Container.RegisterTypeForNavigation<ViewPostDetailPage, ViewPostDetailPageViewModel>();
            Container.RegisterTypeForNavigation<ViewUserDetailPage, ViewUserDetailPageViewModel>();
            Container.RegisterTypeForNavigation<ViewSavedCardsPage, ViewSavedCardsPageViewModel>();
            Container.RegisterTypeForNavigation<ViewCodeDetailPage, ViewCodeDetailPageViewModel>();
        }

        async void CheckForPermissions()
        {
            try
            {
                PermissionStatus status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Camera);
                PermissionStatus status2 = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Storage);

                if (status != PermissionStatus.Granted || status2 != PermissionStatus.Granted)
                {    //It has not been granted so lets ask
                     //if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Location))
                     //{
                     // await this.DisplayAlert("Need location", "Gunna need that location", "OK");
                     //}
                    Dictionary<Permission, PermissionStatus> results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Camera, Permission.Storage });
                    status = results[Permission.Camera];
                    status2 = results[Permission.Storage];
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("\nIn App.Helpers.NetworkHelper.CheckRequestPermissionAsync() - Exception attempting to check or request permission to Permission.{0}:\n{1}\n", Permission.Location, ex);
            }
        }
    }
}

