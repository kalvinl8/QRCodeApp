﻿using System;
using Xamarin.Forms;

namespace QRCodePro.Widgets
{
	public class ImageEntry : Entry
	{
		public static readonly BindableProperty ImageProperty = BindableProperty.Create<ImageEntry, ImageEntryImage>(w => w.Image, ImageEntryImage.None);

		public ImageEntryImage Image
		{
			get { return (ImageEntryImage)GetValue(ImageProperty); }
			set { SetValue(ImageProperty, value); }
		}

		public static readonly BindableProperty ImageAlignmentProperty = BindableProperty.Create<ImageEntry, ImageEntryImageAlignment>(w => w.ImageAlignment, ImageEntryImageAlignment.Left);

		public ImageEntryImageAlignment ImageAlignment
		{
			get { return (ImageEntryImageAlignment)GetValue(ImageAlignmentProperty); }
			set { SetValue(ImageAlignmentProperty, value); }
		}

		public static readonly BindableProperty ImageUrlProperty = BindableProperty.Create<ImageEntry, string>(w => w.ImageUrl, "none.png");

		public string ImageUrl
		{
			get { return (string)GetValue(ImageUrlProperty); }
			set { SetValue(ImageUrlProperty, value); }
		}

		public static readonly BindableProperty BorderColorProperty =
			BindableProperty.Create<ImageEntry, Color>(p => p.BorderColor, Color.Black);

		public Color BorderColor
		{
			get { return (Color)GetValue(BorderColorProperty); }
			set { SetValue(BorderColorProperty, value); }
		}

		public static readonly BindableProperty FontSizeProperty =
			BindableProperty.Create<ImageEntry, double>(p => p.FontSize, Font.Default.FontSize);

		public double FontSize
		{
			get { return (double)GetValue(FontSizeProperty); }
			set { SetValue(FontSizeProperty, value); }
		}

		public static readonly BindableProperty PlaceholderColorProperty =
			BindableProperty.Create<ImageEntry, Color>(p => p.PlaceholderColor, Color.Default);

		public Color PlaceholderColor
		{
			get { return (Color)GetValue(PlaceholderColorProperty); }
			set { SetValue(PlaceholderColorProperty, value); }
		}
	}

	public enum ImageEntryImageAlignment
	{
		Left,
		Right
	}

	public enum ImageEntryImage
	{
		Url,
        Name,
		Email,
		Password,
		Phone,
		None
	}
}
