// Helpers/Settings.cs
using Plugin.Settings;
using Plugin.Settings.Abstractions;

namespace QRCodePro.Helpers
{
	/// <summary>
	/// This is the Settings static class that can be used in your Core solution or in any
	/// of your client applications. All settings are laid out the same exact way with getters
	/// and setters. 
	/// </summary>
	public static class Settings
	{
		private static ISettings AppSettings
		{
			get
			{
				return CrossSettings.Current;
			}
		}

		#region Setting Constants

		private const string SettingsKey = "settings_key";
		private const string UserIdKey = "UserId_key";
        private const string UserProfilePicKey = "UserProfilePic_key";
		private const string UserNameKey = "UserName_key";
		private const string UserEmailKey = "UserEmail_key";
        private const string UserPhoneKey = "UserPhone_key";
        private const string UserTypeKey = "UserType_key";
        private const string UserQRCodePicKey = "UserQRCodePic_key";
        private const string CompanyNameKey = "CompanyName_key";
        private const string CompanyAddressKey = "CompanyAddress_key";
        private const string CompanyWebsiteKey = "CompanyWebsite_key";

		private const string IsLoginKey = "login_flag";

		private static readonly bool BoolDefault = false;
		private static readonly string StringDefault = string.Empty;

		#endregion


		public static string GeneralSettings
		{
			get
			{
				return AppSettings.GetValueOrDefault(SettingsKey, StringDefault);
			}
			set
			{
				AppSettings.AddOrUpdateValue(SettingsKey, value);
			}
		}

		public static string UserId
		{
			get
			{
				return AppSettings.GetValueOrDefault(UserIdKey, StringDefault);
			}
			set
			{
				AppSettings.AddOrUpdateValue(UserIdKey, value);
			}
		}

		public static string UserProfilePic
		{
			get
			{
				return AppSettings.GetValueOrDefault(UserProfilePicKey, StringDefault);
			}
			set
			{
				AppSettings.AddOrUpdateValue(UserProfilePicKey, value);
			}
		}

		public static string UserName
		{
			get
			{
				return AppSettings.GetValueOrDefault(UserNameKey, StringDefault);
			}
			set
			{
				AppSettings.AddOrUpdateValue(UserNameKey, value);
			}
		}

		public static string UserEmail
		{
			get
			{
				return AppSettings.GetValueOrDefault(UserEmailKey, StringDefault);
			}
			set
			{
				AppSettings.AddOrUpdateValue(UserEmailKey, value);
			}
		}

		public static string UserPhone
		{
			get
			{
				return AppSettings.GetValueOrDefault(UserPhoneKey, StringDefault);
			}
			set
			{
				AppSettings.AddOrUpdateValue(UserPhoneKey, value);
			}
		}

		public static string UserType
		{
			get
			{
				return AppSettings.GetValueOrDefault(UserTypeKey, StringDefault);
			}
			set
			{
				AppSettings.AddOrUpdateValue(UserTypeKey, value);
			}
		}

		public static string UserQRCodePic
		{
			get
			{
				return AppSettings.GetValueOrDefault(UserQRCodePicKey, StringDefault);
			}
			set
			{
				AppSettings.AddOrUpdateValue(UserQRCodePicKey, value);
			}
		}

		public static string CompanyName
		{
			get
			{
				return AppSettings.GetValueOrDefault(CompanyNameKey, StringDefault);
			}
			set
			{
				AppSettings.AddOrUpdateValue(CompanyNameKey, value);
			}
		}

		public static string CompanyAddress
		{
			get
			{
				return AppSettings.GetValueOrDefault(CompanyAddressKey, StringDefault);
			}
			set
			{
				AppSettings.AddOrUpdateValue(CompanyAddressKey, value);
			}
		}

		public static string CompanyWebsite
		{
			get
			{
				return AppSettings.GetValueOrDefault(CompanyWebsiteKey, StringDefault);
			}
			set
			{
				AppSettings.AddOrUpdateValue(CompanyWebsiteKey, value);
			}
		}

        public static bool IsLoggedIn
		{
			get
			{
                return AppSettings.GetValueOrDefault(IsLoginKey, BoolDefault);
			}
			set
			{
				AppSettings.AddOrUpdateValue(IsLoginKey, value);
			}
		}

	}
}