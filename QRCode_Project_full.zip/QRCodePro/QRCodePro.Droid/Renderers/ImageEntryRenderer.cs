﻿using System;
using Android.Graphics;
using Android.Graphics.Drawables;
using Android.Support.V4.Content;
using QRCodePro.Droid.Renderers;
using QRCodePro.Widgets;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

[assembly: ExportRenderer(typeof(ImageEntry), typeof(ImageEntryRenderer))]
namespace QRCodePro.Droid.Renderers
{
	class ImageEntryRenderer : EntryRenderer
	{
		protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
		{
			base.OnElementChanged(e);

			//run once when element is first initialized
			if (e.OldElement != null || e.NewElement == null)
			{
				return;
			}

			var element = (ImageEntry)this.Element;
			var editText = this.Control;

			switch (element.ImageAlignment)
			{
				case ImageEntryImageAlignment.Left:
					editText.SetCompoundDrawablesWithIntrinsicBounds(GetDrawable(element.Image), null, null, null);
					break;
				case ImageEntryImageAlignment.Right:
					editText.SetCompoundDrawablesWithIntrinsicBounds(null, null, GetDrawable(element.Image), null);
					break;
				default:
					throw new ArgumentException(
						$"Unknown option for {typeof(ImageEntryImageAlignment).Name} in {typeof(ImageEntryRenderer).Name}",
						nameof(element.ImageAlignment));
			}
			editText.CompoundDrawablePadding = 5;
		}

		private Drawable GetDrawable(ImageEntryImage imageEntryImage)
		{
			switch (imageEntryImage)
			{
                case ImageEntryImage.Url:
                    return GetSizedImage(Resource.Drawable.ic_url);
				case ImageEntryImage.Name:
					return GetSizedImage(Resource.Drawable.ic_name);
				case ImageEntryImage.Email:
					return GetSizedImage(Resource.Drawable.ic_email);
				case ImageEntryImage.Password:
					return GetSizedImage(Resource.Drawable.ic_lock);
				case ImageEntryImage.Phone:
					return GetSizedImage(Resource.Drawable.ic_phone);
				case ImageEntryImage.None:
					throw new ArgumentException(
						$"option None is not a viable image at this point in the function" +
						$" for {typeof(ImageEntryImage).Name} in {typeof(ImageEntryRenderer).Name}",
						nameof(imageEntryImage));
				default:
					throw new ArgumentException(
						$"Unknown option for {typeof(ImageEntryImage).Name} in {typeof(ImageEntryRenderer).Name}",
						nameof(imageEntryImage));
			}
		}

		private Drawable GetSizedImage(int id)
		{
			var drawable = ContextCompat.GetDrawable(this.Context, id);
			var bitmap = ((BitmapDrawable)drawable).Bitmap;
			var heightAndWidth = this.Control.LineHeight;
			return new BitmapDrawable(Resources, Bitmap.CreateScaledBitmap(bitmap, heightAndWidth, heightAndWidth, true));
		}
	}
}