﻿using System;
using System.IO;
using Android.Graphics;
using QRCodePro.Droid.Dependencies;
using QRCodePro.Services;

[assembly: Xamarin.Forms.Dependency(typeof(BarcodeService))]
namespace QRCodePro.Droid.Dependencies
{
	public class BarcodeService : IBarcodeService
	{
		public Stream ConvertImageStream(string text, ZXing.BarcodeFormat format)
		{
			int width = 800;
			int height = 800;

			var barcodeWriter = new ZXing.Mobile.BarcodeWriter
			{
				Format = format,
				Options = new ZXing.Common.EncodingOptions
				{
					Width = width,
					Height = height
				}
			};

			barcodeWriter.Renderer = new ZXing.Mobile.BitmapRenderer();
			var bitmap = barcodeWriter.Write(text);
			var stream = new MemoryStream();
			bitmap.Compress(Bitmap.CompressFormat.Png, 100, stream);  // this is the diff between iOS and Android
			stream.Position = 0;
			return stream;
		}
	}
}
